const mongoose = require('mongoose');
const crypto = require('crypto');

const AuditLogSchema = new mongoose.Schema({
  complaintId: { type: mongoose.Schema.Types.ObjectId, ref: 'Complaint', required: true },
  action: { type: String, required: true }, // 'CREATED', 'STATUS_UPDATE', 'RESOLVED'
  status: { type: String, required: true },
  timestamp: { type: Date, default: Date.now },
  previousHash: { type: String },
  hash: { type: String, unique: true }
});

// Simple hash generation to simulate blockchain immutability
AuditLogSchema.pre('save', async function(next) {
  if (this.isNew) {
    const data = this.complaintId + this.action + this.status + this.timestamp + (this.previousHash || '');
    this.hash = crypto.createHash('sha256').update(data).digest('hex');
  }
  next();
});

module.exports = mongoose.model('AuditLog', AuditLogSchema);
