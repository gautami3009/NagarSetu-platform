import React, { useState, useEffect } from 'react';
import Sidebar, { Role } from './components/layout/Sidebar';
import Navbar from './components/layout/Navbar';
import Dashboard from './pages/Dashboard';
import IssueForm from './components/report/IssueForm';
import ComplaintList from './components/complaints/ComplaintList';
import MapView from './components/map/MapView';
import Login from './pages/Login';
import AdminDashboard from './components/admin/AdminDashboard';
import WorkerDashboard from './components/worker/WorkerDashboard';
import AnalyticsDashboard from './components/admin/AnalyticsDashboard';
import UserManagement from './components/admin/UserManagement';
import Announcements from './components/admin/Announcements';
import ProfileSettings from './components/layout/ProfileSettings';
import { authService, supabase } from './services/api';
import { BotMessageSquare, X, Send } from 'lucide-react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

function App() {
  const [role, setRole] = useState<Role | null>(null);
  const [activeTab, setActiveTab] = useState('dashboard');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // 1. Check current session (Optimized with getSession for speed)
    const loadUser = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (session?.user) {
        const user: any = await authService.getCurrentUser();
        if (user) {
          setRole(user.role);
          setActiveTab(user.role === 'worker' ? 'worker-tasks' : 'dashboard');
        }
      }
      setIsLoading(false);
    };

    loadUser();

    // 2. Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (event, session) => {
      if (event === 'SIGNED_IN' && session) {
        const user: any = await authService.getCurrentUser();
        if (user) setRole(user.role);
      } else if (event === 'SIGNED_OUT') {
        setRole(null);
      }
    });

    return () => subscription.unsubscribe();
  }, []);

  const handleLogin = (r: Role) => {
    setRole(r);
    setActiveTab(r === 'worker' ? 'worker-tasks' : 'dashboard');
  };

  const handleLogout = async () => {
    // Optimistic Logout: Clear state immediately for snappiness
    setRole(null);
    try {
      await authService.logout();
    } catch (e) {
      console.error('Logout error background:', e);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 uppercase tracking-widest text-xs font-bold text-gray-400">
        Syncing City Systems...
      </div>
    );
  }

  if (!role) {
    return <Login onLogin={handleLogin} />;
  }

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return role === 'admin' ? <AdminDashboard /> : <Dashboard />;
      case 'report':
        return <div className="animate-in fade-in slide-in-from-bottom-4"><IssueForm /></div>;
      case 'complaints':
        return <div className="animate-in fade-in slide-in-from-bottom-4"><ComplaintList role={role} /></div>;
      case 'admin-complaints':
        return <div className="animate-in fade-in slide-in-from-bottom-4"><ComplaintList role={role} /></div>;
      case 'worker-tasks':
        return <div className="animate-in fade-in slide-in-from-bottom-4"><WorkerDashboard /></div>;
      case 'map':
        return <div className="animate-in fade-in zoom-in-95"><MapView /></div>;
      case 'analytics':
        return <div className="animate-in fade-in slide-in-from-bottom-4"><AnalyticsDashboard /></div>;
      case 'personnel':
        return <div className="animate-in fade-in slide-in-from-bottom-4"><UserManagement /></div>;
      case 'announcements':
        return <div className="animate-in fade-in slide-in-from-bottom-4"><Announcements /></div>;
      case 'profile':
        return <div className="animate-in fade-in slide-in-from-bottom-4"><ProfileSettings /></div>;
      default:
        return role === 'worker' ? <WorkerDashboard /> : (role === 'admin' ? <AdminDashboard /> : <Dashboard />);
    }
  };

  return (
    <div className="min-h-screen bg-[#fafafa] font-sans">
      {/* Sidebar Overlay for Mobile */}
      {isSidebarOpen && (
        <div 
          className="fixed inset-0 bg-black/20 backdrop-blur-sm z-30 lg:hidden"
          onClick={() => setIsSidebarOpen(false)}
        ></div>
      )}

      {/* Sidebar */}
      <Sidebar 
        role={role}
        activeTab={activeTab} 
        setActiveTab={(tab) => {
          setActiveTab(tab);
          setIsSidebarOpen(false);
        }}
        onLogout={handleLogout}
        className={cn(
          isSidebarOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"
        )}
      />

      {/* Main Content Area */}
      <div className="lg:pl-64 flex flex-col min-h-screen">
        <Navbar toggleSidebar={() => setIsSidebarOpen(!isSidebarOpen)} role={role} />
        
        <main className="flex-1 p-4 lg:p-8 mt-16 max-w-7xl mx-auto w-full">
          {renderContent()}
        </main>

        {/* Global Floating AI Chatbot */}
        <div className="fixed bottom-6 right-6 z-[9999] flex flex-col items-end pointer-events-none">
          {isChatOpen && (
            <div className="mb-4 w-80 sm:w-96 bg-white rounded-2xl shadow-2xl border border-gray-100 overflow-hidden flex flex-col animate-in slide-in-from-bottom-5 pointer-events-auto">
              <div className="bg-primary-600 p-4 flex justify-between items-center text-white">
                <div className="flex items-center gap-2">
                  <BotMessageSquare className="w-5 h-5" />
                  <span className="font-bold">CityPulse AI Support</span>
                </div>
                <button onClick={() => setIsChatOpen(false)} className="text-primary-100 hover:text-white transition-colors">
                  <X className="w-5 h-5" />
                </button>
              </div>
              <div className="h-64 bg-gray-50 p-4 overflow-y-auto space-y-4">
                <div className="flex items-start gap-2 max-w-[85%]">
                  <div className="w-8 h-8 rounded-full bg-primary-100 flex items-center justify-center text-primary-600 shrink-0">
                    <BotMessageSquare className="w-4 h-4" />
                  </div>
                  <div className="bg-white p-3 rounded-2xl rounded-tl-none shadow-sm border border-gray-100 text-sm text-gray-700">
                    Hello! I'm your Smart City Assistant. You can ask me how to report an issue, track a complaint, or inquire about city policies.
                  </div>
                </div>
                {/* Mock user message */}
                <div className="flex items-start gap-2 max-w-[85%] ml-auto">
                  <div className="bg-primary-600 p-3 rounded-2xl rounded-tr-none shadow-sm text-sm text-white">
                    How do I report a pothole?
                  </div>
                </div>
                <div className="flex items-start gap-2 max-w-[85%]">
                  <div className="w-8 h-8 rounded-full bg-primary-100 flex items-center justify-center text-primary-600 shrink-0">
                    <BotMessageSquare className="w-4 h-4" />
                  </div>
                  <div className="bg-white p-3 rounded-2xl rounded-tl-none shadow-sm border border-gray-100 text-sm text-gray-700">
                    You can head to the "Report Issue" tab, upload a quick photo, and our AI will automatically detect that it's a pothole and fill in the details!
                  </div>
                </div>
              </div>
              <div className="p-3 bg-white border-t border-gray-100">
                <div className="relative">
                  <input type="text" placeholder="Type a message..." className="w-full bg-gray-50 border border-gray-200 rounded-xl py-2.5 pl-4 pr-10 text-sm focus:outline-none focus:ring-2 focus:ring-primary-100" />
                  <button className="absolute right-2 top-1/2 -translate-y-1/2 text-primary-600 p-1 hover:bg-primary-50 rounded-lg transition-colors">
                    <Send className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          )}
          <button 
            onClick={() => setIsChatOpen(!isChatOpen)}
            className="w-14 h-14 bg-primary-600 text-white rounded-full flex items-center justify-center shadow-lg shadow-primary-200 hover:scale-105 transition-transform pointer-events-auto"
          >
            {isChatOpen ? <X className="w-6 h-6" /> : <BotMessageSquare className="w-6 h-6" />}
          </button>
        </div>

        <footer className="p-8 text-center text-gray-400 text-xs font-medium">
          &copy; 2026 NagarSetu • Smart City Infrastructure Management • Built for Future Cities
        </footer>
      </div>
    </div>
  );
}

export default App;
