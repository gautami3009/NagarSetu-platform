import React, { useState } from 'react';
import { Shield, User, HardHat, ArrowRight, ArrowLeft, Map as MapIcon, Mail, Lock, Loader2 } from 'lucide-react';
import { Role } from '../components/layout/Sidebar';
import { authService } from '../services/api';

interface LoginProps {
  onLogin: (role: Role) => void;
}

const Login: React.FC<LoginProps> = ({ onLogin }) => {
  const [isLoginTab, setIsLoginTab] = useState(true);
  const [selectedRole, setSelectedRole] = useState<Role | null>(null);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      if (isLoginTab) {
        const { data } = await authService.login({ email, password });
        onLogin(data.user.role || 'citizen');
      } else {
        await authService.signup({ email, password, name, role: selectedRole });
        alert('Check your email for confirmation link!');
        setIsLoginTab(true);
      }
    } catch (err: any) {
      setError(err.message || 'Authentication failed');
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleLogin = async () => {
    try {
      await authService.loginWithGoogle();
    } catch (err: any) {
      setError(err.message);
    }
  };

  if (selectedRole) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 px-4">
        <div className="w-full max-w-md animate-in slide-in-from-right-8 duration-300">
          <button 
            onClick={() => setSelectedRole(null)}
            className="flex items-center gap-2 text-sm font-bold text-gray-500 hover:text-gray-900 mb-6 transition-colors"
          >
            <ArrowLeft className="w-4 h-4" /> Back to roles
          </button>
          
          <div className="bg-white rounded-3xl shadow-soft border border-gray-100 p-8 space-y-6">
            <div className="flex items-center gap-4 mb-2">
              <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                selectedRole === 'admin' ? 'bg-purple-100 text-purple-600' :
                selectedRole === 'worker' ? 'bg-orange-100 text-orange-600' :
                'bg-blue-100 text-blue-600'
              }`}>
                {selectedRole === 'admin' && <Shield className="w-6 h-6" />}
                {selectedRole === 'worker' && <HardHat className="w-6 h-6" />}
                {selectedRole === 'citizen' && <User className="w-6 h-6" />}
              </div>
              <div>
                <h2 className="text-xl font-bold uppercase tracking-wide">
                  {selectedRole === 'admin' ? 'Admin Portal' : selectedRole === 'worker' ? 'Worker Portal' : 'Citizen Portal'}
                </h2>
                <p className="text-sm text-gray-500 font-medium">Please sign in to continue</p>
              </div>
            </div>

            <form onSubmit={handleAuth} className="space-y-4">
              {!isLoginTab && (
                <div className="space-y-1">
                  <label className="text-xs font-bold text-gray-400 uppercase tracking-wider">Full Name</label>
                  <div className="relative">
                    <User className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-300" />
                    <input type="text" value={name} onChange={e => setName(e.target.value)} placeholder="Full Name" className="w-full pl-10 pr-4 py-3 rounded-xl border border-gray-200 focus:outline-none focus:border-primary-500 transition-shadow bg-gray-50" required />
                  </div>
                </div>
              )}
              <div className="space-y-1">
                <label className="text-xs font-bold text-gray-400 uppercase tracking-wider">Email Address</label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-300" />
                  <input type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="example@email.com" className="w-full pl-10 pr-4 py-3 rounded-xl border border-gray-200 focus:outline-none focus:border-primary-500 transition-shadow bg-gray-50" required />
                </div>
              </div>
              
              <div className="space-y-1">
                <label className="text-xs font-bold text-gray-400 uppercase tracking-wider">Password</label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-300" />
                  <input type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="••••••••" className="w-full pl-10 pr-4 py-3 rounded-xl border border-gray-200 focus:outline-none focus:border-primary-500 transition-shadow bg-gray-50" required />
                </div>
              </div>
              
              {error && <p className="text-xs font-bold text-red-500 bg-red-50 p-3 rounded-lg border border-red-100">{error}</p>}

              <button type="submit" disabled={loading} className="w-full bg-primary-600 text-white font-bold py-3.5 rounded-xl hover:bg-primary-700 active:scale-95 transition-all shadow-md shadow-primary-200/50 mt-4 flex items-center justify-center gap-2">
                {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : (isLoginTab ? 'Sign In' : 'Create Account')}
              </button>
            </form>

            <div className="flex items-center gap-4 py-4">
              <div className="flex-1 h-px bg-gray-100"></div>
              <span className="text-xs font-bold text-gray-300 uppercase tracking-widest">OR</span>
              <div className="flex-1 h-px bg-gray-100"></div>
            </div>

            <button 
              onClick={handleGoogleLogin}
              className="w-full flex items-center justify-center gap-3 bg-white border border-gray-200 py-3 rounded-xl hover:bg-gray-50 transition-colors font-bold text-gray-700 shadow-sm"
            >
              <svg className="w-5 h-5" viewBox="0 0 24 24">
                <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
                <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
                <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
                <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
              </svg>
              Sign In with Google
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 px-4">
      <div className="w-full max-w-md animate-in fade-in slide-in-from-bottom-4 duration-500">
        <div className="text-center mb-10">
          <div className="w-16 h-16 bg-primary-600 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-xl shadow-primary-200">
            <MapIcon className="text-white w-8 h-8" />
          </div>
          <h1 className="text-3xl font-extrabold text-gray-900 tracking-tight">NagarSetu</h1>
          <p className="text-gray-500 mt-2 font-medium">Smart City Management Portal</p>
        </div>

        <div className="bg-white rounded-3xl shadow-soft border border-gray-100 p-8 space-y-4">
          
          <div className="flex rounded-xl bg-gray-100 p-1 mb-6">
            <button 
              onClick={() => setIsLoginTab(true)}
              className={`flex-1 py-2 text-sm font-bold rounded-lg transition-all ${isLoginTab ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-500'}`}
            >
              Sign In
            </button>
            <button 
              onClick={() => setIsLoginTab(false)}
              className={`flex-1 py-2 text-sm font-bold rounded-lg transition-all ${!isLoginTab ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-500'}`}
            >
              Sign Up
            </button>
          </div>

          <h3 className="text-sm font-bold text-center text-gray-900 mb-6 py-2 uppercase tracking-wide">Select Your Access Portal</h3>

          <button 
            onClick={() => setSelectedRole('citizen')}
            className="w-full card border-gray-100 hover:border-primary-200 hover:shadow-md group flex items-center justify-between p-4 bg-white"
          >
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-blue-50 rounded-xl flex items-center justify-center text-blue-600 group-hover:bg-blue-600 group-hover:text-white transition-colors">
                <User className="w-6 h-6" />
              </div>
              <div className="text-left">
                <h3 className="font-bold text-gray-900 leading-tight">Resident / Citizen</h3>
                <p className="text-xs text-gray-500 mt-1">Report & track local issues</p>
              </div>
            </div>
            <ArrowRight className="w-5 h-5 text-gray-300 group-hover:text-primary-600 transition-transform group-hover:translate-x-1" />
          </button>

          <button 
            onClick={() => setSelectedRole('worker')}
            className="w-full card border-gray-100 hover:border-orange-200 hover:shadow-md group flex items-center justify-between p-4 bg-white"
          >
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-orange-50 rounded-xl flex items-center justify-center text-orange-600 group-hover:bg-orange-600 group-hover:text-white transition-colors">
                <HardHat className="w-6 h-6" />
              </div>
              <div className="text-left">
                <h3 className="font-bold text-gray-900 leading-tight">Field Worker</h3>
                <p className="text-xs text-gray-500 mt-1">Manage assigned tasks & fixes</p>
              </div>
            </div>
            <ArrowRight className="w-5 h-5 text-gray-300 group-hover:text-orange-600 transition-transform group-hover:translate-x-1" />
          </button>

          <button 
            onClick={() => setSelectedRole('admin')}
            className="w-full card border-gray-100 hover:border-purple-200 hover:shadow-md group flex items-center justify-between p-4 bg-white"
          >
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-purple-50 rounded-xl flex items-center justify-center text-purple-600 group-hover:bg-purple-600 group-hover:text-white transition-colors">
                <Shield className="w-6 h-6" />
              </div>
              <div className="text-left">
                <h3 className="font-bold text-gray-900 leading-tight">City Administrator</h3>
                <p className="text-xs text-gray-500 mt-1">Overview, assign & analytics</p>
              </div>
            </div>
            <ArrowRight className="w-5 h-5 text-gray-300 group-hover:text-purple-600 transition-transform group-hover:translate-x-1" />
          </button>
        </div>
        
        <div className="mt-6 text-center">
          <button 
            onClick={() => onLogin('guest')}
            className="text-gray-400 font-bold hover:text-gray-900 transition-colors uppercase tracking-widest text-xs py-2 px-6 rounded-full hover:bg-white"
          >
            Continue as Guest (Read-Only)
          </button>
        </div>
      </div>
    </div>
  );
};

export default Login;
