import React from 'react';
import { 
  Users, 
  Clock, 
  CheckCircle2, 
  AlertCircle,
  ArrowRight
} from 'lucide-react';
import StatCard from '../components/dashboard/StatCard';
import { ActivityChart, DistributionChart } from '../components/dashboard/DashboardChart';
import LeaderboardCard from '../components/dashboard/LeaderboardCard';
import { reportService } from '../services/api';

const Dashboard = () => {
  const [showExport, setShowExport] = React.useState(false);

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-extrabold text-gray-900 tracking-tight">System Overview</h1>
          <p className="text-gray-500 mt-1">Real-time pulse of city maintenance and reports.</p>
        </div>
        <div className="relative">
          <button 
            onClick={() => setShowExport(!showExport)}
            className="btn-primary flex items-center gap-2"
          >
            Export Reports
            <ArrowRight className={`w-4 h-4 transition-transform ${showExport ? 'rotate-90' : ''}`} />
          </button>
          
          {showExport && (
            <div className="absolute right-0 mt-2 w-48 bg-white rounded-xl shadow-xl border border-gray-100 z-[100] animate-in slide-in-from-top-2 overflow-hidden">
              <button 
                onClick={() => { reportService.downloadReport('pdf'); setShowExport(false); }}
                className="w-full text-left px-4 py-3 text-sm font-bold text-gray-700 hover:bg-gray-50 border-b border-gray-50 flex items-center justify-between"
              >
                Download PDF
                <span className="text-[10px] bg-red-50 text-red-600 px-1.5 py-0.5 rounded uppercase">HQ</span>
              </button>
              <button 
                onClick={() => { reportService.downloadReport('csv'); setShowExport(false); }}
                className="w-full text-left px-4 py-3 text-sm font-bold text-gray-700 hover:bg-gray-50 flex items-center justify-between"
              >
                Download CSV
                <span className="text-[10px] bg-green-50 text-green-600 px-1.5 py-0.5 rounded uppercase">Data</span>
              </button>
            </div>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard 
          title="Total Issues" 
          value="1,284" 
          icon={AlertCircle} 
          trend="+12%" 
          trendUp={true} 
          color="blue" 
        />
        <StatCard 
          title="Pending" 
          value="432" 
          icon={Clock} 
          trend="+5%" 
          trendUp={false} 
          color="yellow" 
        />
        <StatCard 
          title="In Progress" 
          value="156" 
          icon={Users} 
          trend="+18%" 
          trendUp={true} 
          color="blue" 
        />
        <StatCard 
          title="Resolved" 
          value="696" 
          icon={CheckCircle2} 
          trend="+24%" 
          trendUp={true} 
          color="green" 
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <ActivityChart />
        </div>
        <div>
          <DistributionChart />
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div>
          <LeaderboardCard />
        </div>
        <div className="lg:col-span-2 card">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-bold">Recent Activities</h3>
            <button className="text-primary-600 text-sm font-bold hover:underline">View All</button>
          </div>
          <div className="space-y-6">
            {[1, 2, 3].map((i) => (
              <div key={i} className="flex gap-4 group">
                <div className="w-12 h-12 rounded-xl bg-gray-50 flex items-center justify-center text-primary-600 shrink-0 group-hover:bg-primary-50 transition-colors">
                  <CheckCircle2 className="w-6 h-6" />
                </div>
                <div className="flex-1 border-b border-gray-50 pb-4 group-last:border-0">
                  <div className="flex justify-between items-start">
                    <p className="text-sm font-bold text-gray-900">Issue #82V4 resolved by maintenance team</p>
                    <span className="text-xs text-gray-400">12m ago</span>
                  </div>
                  <p className="text-xs text-gray-500 mt-1">Location: Broadway & 5th St • Category: Water Leakage</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
