import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || '';
const supabaseKey = import.meta.env.VITE_SUPABASE_ANON_KEY || '';

export const supabase = createClient(supabaseUrl, supabaseKey);

export const authService = {
  login: async (credentials: any) => {
    const { data, error } = await supabase.auth.signInWithPassword({
      email: credentials.email,
      password: credentials.password,
    });
    if (error) throw error;
    
    // Fetch profile for role
    const { data: profile } = await supabase
      .from('users')
      .select('role')
      .eq('id', data.user.id)
      .single();
      
    return { data: { ...data, user: { ...data.user, role: profile?.role || 'citizen' } } };
  },
  signup: async (userData: any) => {
    const { data, error } = await supabase.auth.signUp({
      email: userData.email,
      password: userData.password,
      options: {
        data: {
          name: userData.name,
          role: userData.role || 'citizen'
        }
      }
    });
    if (error) throw error;
    return { data };
  },
  loginWithGoogle: async () => {
    const { data, error } = await supabase.auth.signInWithOAuth({
      provider: 'google',
    });
    if (error) throw error;
    return data;
  },
  logout: async () => {
    await supabase.auth.signOut();
  },
  getCurrentUser: async () => {
    const { data: { session } } = await supabase.auth.getSession();
    const user = session?.user;
    if (!user) return null;
    
    // Check cache or db for profile
    const { data: profile } = await supabase
      .from('users')
      .select('role')
      .eq('id', user.id)
      .single();
      
    return { ...user, role: profile?.role || 'citizen' };
  }
};

export const complaintService = {
  getComplaints: async () => {
    const { data, error } = await supabase
      .from('complaints')
      .select('*')
      .order('createdAt', { ascending: false });
    
    if (error) throw error;
    return { data: data.map(d => ({ ...d, _id: d.id })) };
  },

  subscribeToComplaints: (callback: (payload: any) => void) => {
    return supabase
      .channel('public:complaints')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'complaints' }, callback)
      .subscribe();
  },

  getComplaintLogs: async (id: string) => {
    const { data, error } = await supabase
      .from('audit_logs')
      .select('*')
      .eq('complaintId', id)
      .order('timestamp', { ascending: true });
    
    if (error) throw error;
    return { data };
  },

  createComplaint: async (formData: FormData) => {
    const title = formData.get('title') as string;
    const description = formData.get('description') as string;
    
    if (!title) throw new Error("Title is required");

    const { data: { user } } = await supabase.auth.getUser();

    let imageUrl = null;
    const imageFile = formData.get('image') as File;
    if (imageFile && imageFile.size > 0) {
      try {
        const fileExt = imageFile.name.split('.').pop();
        const fileName = `${Date.now()}_${Math.random().toString(36).substring(7)}.${fileExt}`;
        const { data: uploadData, error: uploadError } = await supabase.storage
          .from('complaints')
          .upload(fileName, imageFile);
          
        if (uploadError) throw uploadError;
        
        const { data: { publicUrl } } = supabase.storage.from('complaints').getPublicUrl(fileName);
        imageUrl = publicUrl;
      } catch (err) {
        console.error('Image Upload Failed:', err);
      }
    }

    // Convert location to JSON
    let location = null;
    const lat = formData.get('lat');
    const lng = formData.get('lng');
    if (lat && lng) {
      location = {
        lat: parseFloat(lat as string),
        lng: parseFloat(lng as string),
        address: formData.get('address')
      };
    }

    const { data, error } = await supabase
      .from('complaints')
      .insert({
        title,
        description,
        category: formData.get('category'),
        priority: (formData.get('priority') as string)?.toLowerCase() || 'medium',
        imageUrl: imageUrl,
        location: location,
        status: 'Pending',
        user_id: user?.id
      })
      .select()
      .single();

    if (error) {
      console.error('Database Insertion Error:', error);
      throw error;
    }
    
    // Add Audit Log (Non-blocking but logged)
    try {
      await supabase.from('audit_logs').insert({
        complaintId: data.id,
        action: 'CREATED',
        status: 'Pending',
        previousHash: '0000000000000000000000000000000000000000000000000000000000000000'
      });
    } catch (logErr) {
      console.error('Failed to create audit log:', logErr);
    }

    return { data: { ...data, _id: data.id } };
  },

  updateComplaint: async (id: string, formData: FormData) => {
    const status = formData.get('status');
    const updatePayload: any = {};
    if (status) updatePayload.status = status;

    // Handle Proof of Work Image
    const proofFile = formData.get('image') as File;
    if (proofFile && proofFile.size > 0) {
      try {
        const fileExt = proofFile.name.split('.').pop();
        const fileName = `proof_${id}_${Date.now()}.${fileExt}`;
        const { error: uploadError } = await supabase.storage
          .from('complaints')
          .upload(fileName, proofFile);
          
        if (!uploadError) {
          const { data: { publicUrl } } = supabase.storage.from('complaints').getPublicUrl(fileName);
          updatePayload.imageUrl = publicUrl; // Updating main image or we could add proofUrl
        }
      } catch (err) {
        console.error('Proof upload failed:', err);
      }
    }

    const { data, error } = await supabase
      .from('complaints')
      .update(updatePayload)
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;
    
    if (status) {
      const action = status === 'Resolved' ? 'RESOLVED' : 'STATUS_UPDATE';
      await supabase.from('audit_logs').insert({
        complaintId: data.id,
        action: action,
        status: status as string,
        previousHash: '0000000000000000000000000000000000000000000000000000000000000000'
      });
    }

    return { data: { ...data, _id: data.id } };
  }
};

export const reportService = {
  downloadReport: (format: 'pdf' | 'csv', userId?: string) => {
    alert(`Supabase dynamic ${format.toUpperCase()} generation coming soon!`);
  }
};

export default supabase;
