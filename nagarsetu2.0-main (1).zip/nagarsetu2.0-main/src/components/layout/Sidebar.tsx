import React from 'react';
import { 
  LayoutDashboard, 
  AlertCircle, 
  ClipboardList, 
  Map as MapIcon, 
  BarChart3,
  Settings,
  HelpCircle,
  LogOut,
  Users,
  User,
  Megaphone
} from 'lucide-react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export type Role = 'citizen' | 'admin' | 'worker' | 'guest';

interface SidebarProps {
  role: Role;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onLogout: () => void;
  className?: string;
}

const Sidebar: React.FC<SidebarProps> = ({ role, activeTab, setActiveTab, onLogout, className }) => {
  
  const getNavItems = () => {
    switch (role) {
      case 'admin':
        return [
          { icon: LayoutDashboard, label: 'Overview', id: 'dashboard' },
          { icon: ClipboardList, label: 'Manage Complaints', id: 'admin-complaints' },
          { icon: MapIcon, label: 'City Map View', id: 'map' },
          { icon: BarChart3, label: 'Analytics', id: 'analytics' },
          { icon: Users, label: 'Personnel', id: 'personnel' },
          { icon: Megaphone, label: 'Announcements', id: 'announcements' }
        ];
      case 'worker':
        return [
          { icon: ClipboardList, label: 'My Task List', id: 'worker-tasks' },
          { icon: MapIcon, label: 'Task Map', id: 'map' },
        ];
      case 'guest':
        return [
          { icon: LayoutDashboard, label: 'Guest Dashboard', id: 'dashboard' },
          { icon: MapIcon, label: 'City Map View', id: 'map' },
        ];
      case 'citizen':
      default:
        return [
          { icon: LayoutDashboard, label: 'Dashboard', id: 'dashboard' },
          { icon: AlertCircle, label: 'Report Issue', id: 'report' },
          { icon: ClipboardList, label: 'My Complaints', id: 'complaints' },
          { icon: MapIcon, label: 'Map View', id: 'map' },
          { icon: User, label: 'My Profile', id: 'profile' },
        ];
    }
  };

  const navItems = getNavItems();

  return (
    <aside className={cn(
      "w-64 h-screen bg-white border-r border-gray-100 flex flex-col fixed left-0 top-0 z-20 transition-transform duration-300",
      className
    )}>
      <div className="p-6">
        <div className="flex items-center gap-2 mb-8">
          <div className="w-8 h-8 bg-primary-600 rounded-lg flex items-center justify-center">
            <MapIcon className="text-white w-5 h-5" />
          </div>
          <span className="text-xl font-bold bg-gradient-to-r from-primary-700 to-primary-500 bg-clip-text text-transparent">
            NagarSetu
          </span>
        </div>

        <div className="mb-6 px-4">
          <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest bg-gray-50 px-2 py-1 rounded w-full inline-block">
            {role.toUpperCase()} PORTAL
          </span>
        </div>

        <nav className="space-y-1">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={cn(
                "w-full sidebar-link",
                activeTab === item.id && "sidebar-link-active"
              )}
            >
              <item.icon className="w-5 h-5 mr-3" />
              {item.label}
            </button>
          ))}
        </nav>
      </div>

      <div className="mt-auto p-6 border-t border-gray-100 space-y-1">
        <button className="w-full sidebar-link text-red-500 hover:bg-red-50 hover:text-red-600" onClick={onLogout}>
          <LogOut className="w-5 h-5 mr-3" />
          Logout
        </button>
      </div>
    </aside>
  );
};

export default Sidebar;
