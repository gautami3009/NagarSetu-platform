import React, { useState } from 'react';
import { User, Mail, Phone, MapPin, Save, Camera } from 'lucide-react';

const ProfileSettings = () => {
  const [isEditing, setIsEditing] = useState(false);

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div>
        <h2 className="text-2xl font-bold mb-2">My Profile</h2>
        <p className="text-gray-500">Manage your citizen account and notification preferences.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-1 space-y-4">
          <div className="card p-6 flex flex-col items-center text-center">
            <div className="relative group cursor-pointer mb-4">
              <div className="w-32 h-32 rounded-full overflow-hidden border-4 border-white shadow-xl relative bg-primary-100 flex items-center justify-center text-primary-600">
                <User className="w-16 h-16" />
                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center text-white">
                  <Camera className="w-6 h-6 mb-1" />
                  <span className="text-xs font-bold">Change</span>
                </div>
              </div>
            </div>
            <h3 className="text-xl font-bold">Sarah Chen</h3>
            <p className="text-gray-500 text-sm">Residency Verified</p>
            <div className="mt-4 px-4 py-2 bg-green-50 text-green-700 font-bold text-xs uppercase tracking-wider rounded-lg border border-green-200">
              Active Citizen
            </div>
          </div>
        </div>

        <div className="md:col-span-2">
          <div className="card p-6">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-lg font-bold">Personal Information</h3>
              <button 
                onClick={() => setIsEditing(!isEditing)}
                className="btn-secondary py-1.5 px-4 text-sm"
              >
                {isEditing ? 'Cancel' : 'Edit Profile'}
              </button>
            </div>

            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-gray-500 uppercase tracking-wider">Full Name</label>
                  <div className="relative">
                    <User className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                    <input type="text" disabled={!isEditing} defaultValue="Sarah Chen" className="input-field pl-10 bg-gray-50 disabled:opacity-75 disabled:cursor-not-allowed" />
                  </div>
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-bold text-gray-500 uppercase tracking-wider">Email Address</label>
                  <div className="relative">
                    <Mail className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                    <input type="email" disabled={!isEditing} defaultValue="sarah.c@example.com" className="input-field pl-10 bg-gray-50 disabled:opacity-75 disabled:cursor-not-allowed" />
                  </div>
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-bold text-gray-500 uppercase tracking-wider">Phone Number</label>
                  <div className="relative">
                    <Phone className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                    <input type="text" disabled={!isEditing} defaultValue="+91 98765 43210" className="input-field pl-10 bg-gray-50 disabled:opacity-75 disabled:cursor-not-allowed" />
                  </div>
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-bold text-gray-500 uppercase tracking-wider">Residential Area</label>
                  <div className="relative">
                    <MapPin className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                    <input type="text" disabled={!isEditing} defaultValue="Mahadwar Road, Kolhapur" className="input-field pl-10 bg-gray-50 disabled:opacity-75 disabled:cursor-not-allowed" />
                  </div>
                </div>
              </div>

              {isEditing && (
                <div className="pt-4 border-t border-gray-100 flex justify-end">
                  <button onClick={() => setIsEditing(false)} className="btn-primary flex items-center gap-2">
                    <Save className="w-4 h-4" /> Save Changes
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProfileSettings;
