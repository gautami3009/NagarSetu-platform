import React from 'react';
import { Bell, User, Search, Menu, AlertCircle, Globe, CloudOff } from 'lucide-react';
import { Role } from './Sidebar';

interface NavbarProps {
  role: Role | null;
  toggleSidebar: () => void;
}

const Navbar: React.FC<NavbarProps> = ({ role, toggleSidebar }) => {

  const getUserDetails = () => {
    switch(role) {
      case 'admin': return { name: 'Admin User', desc: 'City Administrator' };
      case 'worker': return { name: 'Field Squad A', desc: 'Maintenance Worker' };
      case 'citizen': 
      default: return { name: 'Sarah Chen', desc: 'Resident' };
    }
  };

  const userDetails = getUserDetails();

  return (
    <header className="h-16 bg-white border-b border-gray-100 flex items-center justify-between px-4 lg:px-8 fixed top-0 right-0 left-0 lg:left-64 z-10 transition-all duration-300">
      <div className="flex items-center gap-4">
        <button 
          onClick={toggleSidebar}
          className="lg:hidden p-2 hover:bg-gray-50 rounded-lg"
        >
          <Menu className="w-6 h-6 text-gray-600" />
        </button>
        
        <div className="relative hidden md:block group">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 group-focus-within:text-primary-500 transition-colors" />
          <input 
            type="text" 
            placeholder="Search city systems..."
            className="pl-10 pr-4 py-2 bg-gray-50 border-gray-100 border rounded-xl text-sm focus:bg-white focus:ring-2 focus:ring-primary-100 w-64 xl:w-96 transition-all outline-none"
          />
        </div>
      </div>

      <div className="flex items-center gap-2 md:gap-4">
        {/* Offline Ready Badge (Simulation) */}
        <div className="hidden lg:flex items-center gap-1.5 px-2 py-1 bg-green-50 text-green-600 rounded text-[10px] font-bold uppercase tracking-wider border border-green-100 cursor-help" title="Application works offline & syncs automatically.">
           <CloudOff className="w-3 h-3" /> Sync Ready
        </div>

        {/* Multi-language Toggle */}
        <div className="relative group mx-2">
          <button className="flex items-center gap-1 text-gray-500 hover:text-primary-600 transition-colors">
            <Globe className="w-5 h-5" />
            <span className="text-xs font-bold uppercase hidden sm:block">EN</span>
          </button>
          <div className="absolute right-0 top-8 bg-white shadow-xl rounded border border-gray-100 p-2 opacity-0 pointer-events-none group-hover:opacity-100 group-hover:pointer-events-auto transition-all w-24">
             <button className="w-full text-left text-sm px-2 py-1 hover:bg-gray-50 rounded font-bold text-gray-900">EN - English</button>
             <button className="w-full text-left text-sm px-2 py-1 hover:bg-gray-50 rounded font-medium text-gray-600">HI - हिंदी</button>
             <button className="w-full text-left text-sm px-2 py-1 hover:bg-gray-50 rounded font-medium text-gray-600">MR - मराठी</button>
          </div>
        </div>

        <button className="relative p-2 hover:bg-gray-50 rounded-full transition-colors group">
          <Bell className="w-5 h-5 text-gray-600 group-hover:text-primary-600" />
          <span className="absolute top-2 right-2 w-2 h-2 bg-red-500 rounded-full border-2 border-white"></span>
          
          {/* Notification Dropdown UI */}
          <div className="absolute right-0 top-12 w-80 bg-white shadow-2xl rounded-2xl border border-gray-100 p-4 opacity-0 scale-95 pointer-events-none group-hover:opacity-100 group-hover:pointer-events-auto group-hover:scale-100 transition-all duration-200 origin-top-right">
            <h3 className="font-bold mb-3 text-left">Notifications</h3>
            {role === 'worker' ? (
               <div className="space-y-3 text-left">
                 <div className="flex gap-3 p-2 hover:bg-gray-50 rounded-lg transition-colors cursor-pointer">
                   <div className="w-10 h-10 bg-orange-50 rounded-full flex items-center justify-center text-orange-600 shrink-0">
                     <AlertCircle className="w-5 h-5" />
                   </div>
                   <div>
                     <p className="text-sm font-medium text-gray-900">New Task Assigned: Pothole Repair</p>
                     <p className="text-xs text-gray-400 mt-0.5">10 mins ago</p>
                   </div>
                 </div>
               </div>
            ) : (
                <div className="space-y-3 text-left">
                  {[1, 2].map((i) => (
                    <div key={i} className="flex gap-3 p-2 hover:bg-gray-50 rounded-lg transition-colors cursor-pointer">
                      <div className="w-10 h-10 bg-primary-50 rounded-full flex items-center justify-center text-primary-600 shrink-0">
                        <Bell className="w-5 h-5" />
                      </div>
                      <div>
                        <p className="text-sm font-medium text-gray-900">Issue #{482 + i} status was updated.</p>
                        <p className="text-xs text-gray-400 mt-0.5">{i * 2} hours ago</p>
                      </div>
                    </div>
                  ))}
                </div>
            )}
            <button className="w-full text-center text-xs font-bold text-primary-600 mt-3 pt-3 border-t border-gray-100 hover:text-primary-700">
              View All Notifications
            </button>
          </div>
        </button>

        <div className="h-8 w-px bg-gray-100 mx-2 hidden sm:block"></div>

        <button className="flex items-center gap-3 p-1.5 pr-3 hover:bg-gray-50 rounded-xl transition-all border border-transparent hover:border-gray-100">
          <div className="w-8 h-8 rounded-lg bg-primary-100 flex items-center justify-center">
            <User className="w-5 h-5 text-primary-600" />
          </div>
          <div className="hidden sm:block text-left">
            <p className="text-sm font-bold text-gray-900 leading-none">{userDetails.name}</p>
            <p className="text-[10px] text-gray-400 font-medium leading-none mt-1">{userDetails.desc}</p>
          </div>
        </button>
      </div>
    </header>
  );
};

export default Navbar;
