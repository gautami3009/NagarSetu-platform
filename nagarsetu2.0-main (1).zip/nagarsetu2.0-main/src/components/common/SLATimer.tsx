import React, { useState, useEffect } from 'react';
import { Clock, AlertTriangle } from 'lucide-react';

interface SLATimerProps {
  initialHours: number;
  initialMinutes?: number;
  priority?: 'high' | 'medium' | 'low';
}

const SLATimer: React.FC<SLATimerProps> = ({ initialHours, initialMinutes = 0, priority = 'normal' }) => {
  const [timeLeft, setTimeLeft] = useState(initialHours * 3600 + initialMinutes * 60);

  useEffect(() => {
    if (timeLeft <= 0) return;

    const intervalId = setInterval(() => {
      setTimeLeft(prev => prev - 1);
    }, 1000);

    return () => clearInterval(intervalId);
  }, [timeLeft]);

  const h = Math.floor(timeLeft / 3600);
  const m = Math.floor((timeLeft % 3600) / 60);
  const s = timeLeft % 60;

  const isUrgent = timeLeft < 3600 * 2; // less than 2 hours
  const isBreached = timeLeft <= 0;

  let colorClass = 'bg-blue-50 text-blue-700 border-blue-100';
  if (priority === 'high' || isUrgent) colorClass = 'bg-orange-50 text-orange-700 border-orange-100';
  if (isBreached) colorClass = 'bg-red-50 text-red-700 border-red-100';

  return (
    <div className={`flex items-center gap-2 px-3 py-1.5 rounded-lg border font-mono text-sm font-bold ${colorClass}`}>
      {isBreached || isUrgent ? (
        <AlertTriangle className="w-4 h-4 animate-pulse" />
      ) : (
        <Clock className="w-4 h-4" />
      )}
      <span>
        {isBreached ? 'SLA BREACHED' : `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`}
      </span>
    </div>
  );
};

export default SLATimer;
