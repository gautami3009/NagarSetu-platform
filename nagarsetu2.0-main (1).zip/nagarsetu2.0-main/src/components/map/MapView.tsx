import React, { useState } from 'react';
import { Search, MapPin, Navigation, Star, X } from 'lucide-react';
import { MapContainer, TileLayer, Marker, Popup, useMap, useMapEvents, Circle } from 'react-leaflet';
import L from 'leaflet';

// Fix for default Leaflet icon not showing in React properly
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
});

// Custom icons based on status
const createIcon = (color: string) => {
  return new L.DivIcon({
    className: 'custom-leaflet-icon',
    html: `<div style="background-color: ${color}; width: 24px; height: 24px; border-radius: 50%; border: 3px solid white; box-shadow: 0 2px 5px rgba(0,0,0,0.3); display: flex; align-items: center; justify-center: center;"></div>`,
    iconSize: [24, 24],
    iconAnchor: [12, 12],
    popupAnchor: [0, -12]
  });
};

const iconYellow = createIcon('#eab308'); // pending
const iconBlue = createIcon('#3b82f6'); // progress
const iconGreen = createIcon('#22c55e'); // resolved

const mockIssues = [
  { id: 1, title: 'Broken Light', location: 'Mahadwar Road, Kolhapur', lat: 16.6950, lng: 74.2250, status: 'Pending', icon: iconYellow, reporter: 'Ramesh P.' },
  { id: 2, title: 'Road Damage', location: 'Tarabai Park', lat: 16.7110, lng: 74.2410, status: 'In Progress', icon: iconBlue, reporter: 'Priya M.' },
  { id: 3, title: 'Garbage Dump', location: 'Rajarampuri', lat: 16.7020, lng: 74.2510, status: 'Resolved', icon: iconGreen, reporter: 'Amit D.' },
  { id: 4, title: 'Water Pipe Leak', location: 'Shahupuri', lat: 16.7050, lng: 74.2380, status: 'Pending', icon: iconYellow, reporter: 'Sneha K.' }
];

const LocationMarker = ({ position, setPosition }: any) => {
  useMapEvents({
    click(e) {
      setPosition(e.latlng);
    },
  });

  return position === null ? null : (
    <Marker position={position} icon={iconBlue}>
      <Popup className="rounded-xl font-bold">New reported location!</Popup>
    </Marker>
  );
};

const MapView = () => {
  const [selectedIssue, setSelectedIssue] = useState<any>(null);
  const [newMarkerPos, setNewMarkerPos] = useState<any>(null);

  // Center on Kolhapur, Maharashtra
  const position: [number, number] = [16.7050, 74.2433];

  return (
    <div className="relative h-[calc(100vh-140px)] rounded-3xl overflow-hidden border border-gray-100 shadow-soft isolation-auto">
      <MapContainer center={position} zoom={12} style={{ height: '100%', width: '100%', zIndex: 0 }}>
        <TileLayer
          attribution='&copy; OpenStreetMap contributors'
          url="https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png"
        />
        
        <LocationMarker position={newMarkerPos} setPosition={setNewMarkerPos} />

        {/* Hotspot UI Simulation */}
        <Circle center={[16.7110, 74.2410]} pathOptions={{ color: 'red', fillColor: 'red', fillOpacity: 0.2 }} radius={800}>
          <Popup className="rounded-xl">
             <div className="font-bold text-red-600">CRITICAL HOTSPOT</div>
             <div className="text-xs text-gray-500">High volume of Pothole reports</div>
          </Popup>
        </Circle>

        {mockIssues.map(issue => (
          <Marker 
            key={issue.id} 
            position={[issue.lat, issue.lng]} 
            icon={issue.icon}
            eventHandlers={{
              click: () => setSelectedIssue(issue),
            }}
          >
            <Popup className="rounded-xl">
              <div className="font-bold text-gray-900">{issue.title}</div>
              <div className="text-xs text-gray-500">{issue.status}</div>
            </Popup>
          </Marker>
        ))}
      </MapContainer>

      {/* Floating Controls */}
      <div className="absolute top-6 left-6 right-6 flex justify-between items-start pointer-events-none z-[1000]">
        <div className="w-full max-w-sm pointer-events-auto">
          <div className="relative group shadow-xl rounded-2xl">
            <Search className="w-4 h-4 absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 group-focus-within:text-primary-500 transition-colors" />
            <input 
              type="text" 
              placeholder="Search by area or issue ID..."
              className="w-full pl-11 pr-4 py-3.5 bg-white/95 backdrop-blur-md rounded-2xl border border-white focus:ring-4 focus:ring-primary-50 focus:border-primary-100 transition-all outline-none text-sm font-medium"
            />
          </div>
        </div>

        <div className="flex flex-col gap-2 pointer-events-auto ml-2">
          <button className="p-3 bg-white/95 backdrop-blur-md rounded-xl border border-white shadow-lg text-gray-600 hover:text-primary-600 transition-all">
            <Navigation className="w-5 h-5" />
          </button>
          <button className="p-3 bg-white/95 backdrop-blur-md rounded-xl border border-white shadow-lg text-gray-600 hover:text-primary-600 transition-all">
            <Star className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Selected Issue Floating Card */}
      {selectedIssue && (
        <div className="absolute bottom-6 left-6 right-6 lg:left-auto lg:right-6 lg:w-96 animate-in slide-in-from-bottom-5 duration-300 z-[1000]">
          <div className="card !p-0 overflow-hidden shadow-2xl border-white bg-white/95 backdrop-blur-xl">
            <div className="p-5 border-b border-gray-100 flex justify-between items-start">
              <div>
                <span className={`px-2 py-1 text-xs font-bold rounded tracking-wider uppercase mb-2 inline-block ${
                  selectedIssue.status === 'Pending' ? 'bg-yellow-100 text-yellow-700' :
                  selectedIssue.status === 'In Progress' ? 'bg-blue-100 text-blue-700' :
                  'bg-green-100 text-green-700'
                }`}>{selectedIssue.status}</span>
                <h3 className="text-lg font-extrabold text-gray-900 leading-tight">{selectedIssue.title}</h3>
                <p className="text-sm font-medium text-gray-500 flex items-center gap-1.5 mt-2">
                  <MapPin className="w-3.5 h-3.5" /> {selectedIssue.location}
                </p>
              </div>
              <button 
                onClick={() => setSelectedIssue(null)}
                className="p-1 hover:bg-gray-100 rounded-lg text-gray-400 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <div className="p-5 space-y-4">
              <div className="flex justify-between text-[10px] font-extrabold text-gray-400 uppercase tracking-widest">
                <span>Reporter</span>
                <span>Assigned Dept</span>
              </div>
              <div className="flex justify-between items-center text-sm font-bold -mt-2">
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 bg-primary-100 rounded text-[10px] flex items-center justify-center text-primary-700">{selectedIssue.reporter.substring(0,2).toUpperCase()}</div>
                  <span className="text-gray-900">{selectedIssue.reporter}</span>
                </div>
                <span className="text-primary-600 bg-primary-50 px-2 py-0.5 rounded">Public Works</span>
              </div>
              
              <div className="grid grid-cols-2 gap-3 pt-4 border-t border-gray-100">
                <button className="py-2.5 bg-white border border-gray-200 text-gray-700 rounded-xl font-bold text-sm hover:bg-gray-50 transition-colors">
                  View Details
                </button>
                <button className="py-2.5 bg-primary-600 text-white rounded-xl font-bold text-sm hover:bg-primary-700 transition-colors shadow-lg shadow-primary-200">
                  Dispatch Crew
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Map Legend */}
      <div className="absolute bottom-6 left-6 hidden lg:flex gap-4 p-3 bg-white/95 backdrop-blur-md rounded-2xl border border-white shadow-xl z-[1000]">
        <div className="flex items-center gap-2 text-xs font-bold text-gray-600">
          <div className="w-3 h-3 rounded-full bg-yellow-500 shadow-sm"></div>
          Pending Reporting
        </div>
        <div className="flex items-center gap-2 text-xs font-bold text-gray-600">
          <div className="w-3 h-3 rounded-full bg-blue-500 shadow-sm"></div>
          Crew En Route
        </div>
        <div className="flex items-center gap-2 text-xs font-bold text-gray-600">
          <div className="w-3 h-3 rounded-full bg-green-500 shadow-sm"></div>
          Issue Resolved
        </div>
      </div>
    </div>
  );
};

export default MapView;
