import React, { useEffect, useState } from 'react';
import { Shield, Clock, Hash, CheckCircle2, AlertCircle, ArrowRight } from 'lucide-react';
import { complaintService } from '../../services/api';

interface Log {
  _id: string;
  action: string;
  status: string;
  timestamp: string;
  previousHash: string;
  hash: string;
}

const BlockchainLogs = ({ complaintId, onClose }: { complaintId: string, onClose: () => void }) => {
  const [logs, setLogs] = useState<Log[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchLogs = async () => {
      try {
        const res = await complaintService.getComplaintLogs(complaintId);
        setLogs(res.data);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchLogs();
  }, [complaintId]);

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[1000] flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white w-full max-w-2xl rounded-3xl shadow-2xl overflow-hidden animate-in zoom-in-95 duration-300">
        <div className="bg-primary-600 p-6 flex justify-between items-center text-white">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center">
              <Shield className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-xl font-bold">Immutable Audit Ledger</h2>
              <p className="text-xs text-primary-100 uppercase tracking-widest font-bold mt-1">Blockchain-Verified Logs</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-white/10 rounded-lg transition-colors font-bold">Close</button>
        </div>

        <div className="p-8 bg-gray-50/50 max-h-[70vh] overflow-y-auto custom-scrollbar">
          {loading ? (
            <div className="flex justify-center py-20">
              <div className="w-10 h-10 border-4 border-primary-200 border-t-primary-600 rounded-full animate-spin"></div>
            </div>
          ) : logs.length === 0 ? (
            <div className="text-center py-20">
              <AlertCircle className="w-12 h-12 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-500 font-bold uppercase tracking-wider text-sm">No Audit History Found</p>
            </div>
          ) : (
            <div className="space-y-8 relative before:absolute before:left-[17px] before:top-2 before:bottom-2 before:w-0.5 before:bg-gray-200">
              {logs.map((log, index) => (
                <div key={log._id} className="relative pl-12 group">
                  <div className={`absolute left-0 top-0 w-9 h-9 rounded-full flex items-center justify-center z-10 transition-transform group-hover:scale-110 ${
                    log.action === 'CREATED' ? 'bg-blue-100 text-blue-600' :
                    log.action === 'RESOLVED' ? 'bg-green-100 text-green-600' :
                    'bg-amber-100 text-amber-600'
                  } border-2 border-white ring-4 ring-gray-200/50 shadow-sm`}>
                    {log.action === 'CREATED' && <AlertCircle className="w-5 h-5" />}
                    {log.action === 'RESOLVED' && <CheckCircle2 className="w-5 h-5" />}
                    {(log.action !== 'CREATED' && log.action !== 'RESOLVED') && <Clock className="w-5 h-5" />}
                  </div>

                  <div className="card border-gray-100 hover:border-primary-100 transition-all bg-white p-5 group-hover:shadow-md">
                    <div className="flex justify-between items-start mb-4">
                      <div>
                        <h4 className="font-bold text-gray-900 uppercase tracking-wide text-xs mb-1">{log.action}</h4>
                        <p className="text-sm font-bold text-gray-500">{new Date(log.timestamp).toLocaleString()}</p>
                      </div>
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
                        log.status === 'Resolved' ? 'bg-green-100 text-green-700' :
                        log.status === 'In Progress' ? 'bg-blue-100 text-blue-700' :
                        'bg-amber-100 text-amber-700'
                      }`}>
                        {log.status}
                      </span>
                    </div>

                    <div className="space-y-2 bg-gray-50 p-3 rounded-xl border border-gray-100">
                      <div className="flex items-center gap-2">
                        <Hash className="w-3 h-3 text-gray-400" />
                        <span className="text-[10px] text-gray-400 font-mono font-bold uppercase tracking-widest text-ellipsis overflow-hidden">Curr Hash:</span>
                        <span className="text-[10px] text-primary-600 font-mono font-bold break-all lowercase">{log.hash}</span>
                      </div>
                      <div className="flex items-center gap-2 opacity-60">
                        <ArrowRight className="w-3 h-3 text-gray-400" />
                        <span className="text-[10px] text-gray-400 font-mono font-bold uppercase tracking-widest">Prev Hash:</span>
                        <span className="text-[10px] text-gray-500 font-mono font-bold break-all lowercase">{log.previousHash}</span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
        
        <div className="p-4 bg-gray-100 text-center">
          <p className="text-[10px] text-gray-400 font-bold uppercase tracking-[0.2em]">Verified Immutable Record • NagarSetu Ledger v2.0</p>
        </div>
      </div>
    </div>
  );
};

export default BlockchainLogs;
