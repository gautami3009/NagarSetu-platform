import React, { useEffect, useState } from 'react';
import { Search, Filter, MoreVertical, MapPin, Calendar, Clock, AlertTriangle, UserCheck, Shield, Layers, Star, Share2, MessageCircle } from 'lucide-react';
import { Role } from '../layout/Sidebar';
import { complaintService } from '../../services/api';
import BlockchainLogs from './BlockchainLogs';

const DEMO_COMPLAINTS = [
  {
    _id: 'DEMO-001',
    title: 'Example: Urban Pothole',
    description: 'This is a sample report showing how road damage appears in the system.',
    category: 'Road & Pavement',
    status: 'Pending',
    createdAt: new Date().toISOString(),
    location: { address: 'Mahadwar Road, Kolhapur' },
    imageUrl: null,
    isDemo: true
  },
  {
    _id: 'DEMO-002',
    title: 'Example: Street Light Issue',
    description: 'A demonstration of a lighting failure report. These are resolved by the utility squad.',
    category: 'Street Lights',
    status: 'In Progress',
    createdAt: new Date().toISOString(),
    location: { address: 'Rajarampuri, Kolhapur' },
    imageUrl: null,
    isDemo: true
  }
];

const StatusBadge = ({ status }: { status: string }) => {
  switch (status) {
    case 'Pending': return <span className="badge-pending bg-amber-100 text-amber-700 border-amber-200">PENDING</span>;
    case 'In Progress': return <span className="badge-progress bg-blue-100 text-blue-700 border-blue-200">IN PROGRESS</span>;
    case 'Resolved': return <span className="badge-resolved bg-green-100 text-green-700 border-green-200">RESOLVED</span>;
    default: return <span className="badge-pending">{status.toUpperCase()}</span>;
  }
};

const SourceBadge = ({ isDemo }: { isDemo?: boolean }) => {
  if (isDemo) return <span className="flex items-center gap-1 text-[10px] font-bold text-gray-500 bg-gray-100 px-2 py-0.5 rounded uppercase tracking-wider">Demo Mode</span>;
  return <span className="flex items-center gap-1 text-[10px] font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-100 uppercase tracking-wider">Live Report</span>;
};

interface ComplaintListProps {
  role?: Role;
}

let complaintsCache: any[] | null = null;

const ComplaintList: React.FC<ComplaintListProps> = ({ role = 'citizen' }) => {
  const [statusFilter, setStatusFilter] = useState('All');
  const [sourceFilter, setSourceFilter] = useState('All');
  const [realComplaints, setRealComplaints] = useState<any[]>(complaintsCache || []);
  const [loading, setLoading] = useState(!complaintsCache);
  const [showLogs, setShowLogs] = useState<string | null>(null);

  const fetchComplaints = async () => {
    try {
      const res = await complaintService.getComplaints();
      const formatted = res.data.map((c: any) => ({ ...c, isDemo: false }));
      
      // Load from LocalStorage fallback if any exist
      const localData = JSON.parse(localStorage.getItem('local_complaints') || '[]');
      const combined = [...localData, ...formatted];

      complaintsCache = combined;
      setRealComplaints(combined);
    } catch (err) {
      console.error('Failed to fetch real data, checking local storage');
      const localData = JSON.parse(localStorage.getItem('local_complaints') || '[]');
      setRealComplaints(localData);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchComplaints();

    // 🏆 Real-time Subscription
    const subscription = complaintService.subscribeToComplaints((payload) => {
      console.log('🔔 Real-time Update Received:', payload);
      // Re-fetch all to keep it simple, or patch locally for performance
      fetchComplaints();
    });

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  const combinedData = [...realComplaints, ...DEMO_COMPLAINTS];
  
  const filteredData = combinedData.filter(item => {
    const sMatch = statusFilter === 'All' || item.status === statusFilter;
    const srcMatch = sourceFilter === 'All' || 
                   (sourceFilter === 'Real' && !item.isDemo) || 
                   (sourceFilter === 'Demo' && item.isDemo);
    return sMatch && srcMatch;
  });

  const handleStatusUpdate = async (id: string, newStatus: string) => {
    try {
      const formData = new FormData();
      formData.append('status', newStatus);
      await complaintService.updateComplaint(id, formData);
      fetchComplaints();
    } catch (err) {
      alert('Cannot update demo complaints.');
    }
  };
  
  const handleAssign = (id: string) => {
    handleStatusUpdate(id, 'In Progress');
  };

  const handleEscalate = (id: string) => {
    alert(`Issue ${id} has been escalated to city management!`);
  };

  const shareSocial = (platform: string, title: string) => {
    alert(`Opening ${platform} sharing intent for: "${title}"`);
  };

  const handleRating = (id: string, stars: number) => {
    alert(`Thank you! You rated the resolution to #${id.slice(-6)} with ${stars} stars.`);
  };

  if (loading) return (
    <div className="space-y-4 pt-4">
      <div className="h-8 w-1/3 bg-gray-200 rounded animate-pulse mb-6"></div>
      {[...Array(3)].map((_, i) => (
        <div key={i} className="card p-4 lg:p-6 flex flex-col md:flex-row gap-4">
          <div className="w-full md:w-48 h-48 md:h-32 bg-gray-200 rounded-xl animate-pulse shrink-0"></div>
          <div className="flex-1 space-y-3 py-2">
            <div className="h-4 w-24 bg-gray-200 rounded animate-pulse"></div>
            <div className="h-6 w-3/4 bg-gray-200 rounded animate-pulse"></div>
            <div className="h-4 w-full bg-gray-200 rounded animate-pulse"></div>
            <div className="h-4 w-1/2 bg-gray-200 rounded animate-pulse"></div>
          </div>
        </div>
      ))}
    </div>
  );

  return (
    <div className="space-y-6">
      {showLogs && <BlockchainLogs complaintId={showLogs} onClose={() => setShowLogs(null)} />}
      
      <div className="flex flex-col xl:flex-row justify-between items-start xl:items-center gap-6">
        <div>
          <h2 className="text-2xl font-bold">
            {role === 'admin' ? 'Infrastructure Pulse' : 'Citizen Incident Reports'}
          </h2>
          <p className="text-gray-500">
            {role === 'admin' ? 'Monitoring city-wide service requests and SLAs.' : 'Track and manage your submitted city reports.'}
          </p>
        </div>
        
        <div className="flex flex-wrap gap-4">
          <div className="flex bg-gray-100 p-1 rounded-xl border border-gray-200 shadow-inner">
            {['All', 'Real', 'Demo'].map((sf) => (
              <button key={sf}
                onClick={() => setSourceFilter(sf)}
                className={`px-4 py-1.5 rounded-lg text-xs font-bold transition-all
                  ${sourceFilter === sf ? 'bg-white text-primary-600 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
              >
                {sf}
              </button>
            ))}
          </div>

          <div className="flex gap-2 overflow-x-auto pb-1 sm:pb-0 hide-scrollbar">
            {['All', 'Pending', 'In Progress', 'Resolved'].map((f) => (
              <button key={f}
                onClick={() => setStatusFilter(f)}
                className={`px-4 py-1.5 rounded-xl text-xs font-bold transition-all border whitespace-nowrap
                  ${statusFilter === f 
                    ? 'bg-primary-600 text-white border-primary-600 shadow-md' 
                    : 'bg-white text-gray-400 border-gray-100 hover:border-primary-200'}`}
              >
                {f}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-4">
        {filteredData.map((item) => (
          <div key={item._id} className="card group flex flex-col md:flex-row gap-4 p-4 lg:p-6 transition-all hover:border-primary-200 relative overflow-hidden">
            {!item.isDemo && (
              <div className="absolute top-0 right-0 w-24 h-24 bg-primary-50 -mr-12 -mt-12 rounded-full opacity-20 pointer-events-none group-hover:scale-150 transition-transform duration-700"></div>
            )}
            
            <div className="w-full md:w-48 h-48 md:h-32 rounded-xl overflow-hidden shrink-0 border border-gray-100 relative bg-gray-50">
              <img src={item.imageUrl ? (item.imageUrl.startsWith('http') ? item.imageUrl : `http://localhost:5000${item.imageUrl}`) : 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&q=80&w=200'} alt="" loading="lazy" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
              {!item.isDemo && (
                <div className="absolute top-2 left-2 px-1.5 py-0.5 bg-primary-600 text-[8px] text-white font-bold rounded flex items-center gap-1 shadow-md">
                  <Shield className="w-2.5 h-2.5" /> VERIFIED
                </div>
              )}
            </div>
            
            <div className="flex-1 min-w-0 flex flex-col justify-between">
              <div>
                <div className="flex justify-between items-start mb-2">
                  <div className="flex items-center gap-2">
                    <StatusBadge status={item.status} />
                    <SourceBadge isDemo={item.isDemo} />
                  </div>
                  <span className="text-[10px] font-bold text-gray-400 font-mono tracking-tighter">
                    #{item._id.slice(-8).toUpperCase()}
                  </span>
                </div>
                
                <h4 className="text-lg font-bold text-gray-900 leading-tight mb-1">{item.title}</h4>
                <p className="text-sm text-gray-500 line-clamp-2 md:line-clamp-1 mb-3">{item.description}</p>
                
                <div className="flex flex-wrap items-center gap-4 text-xs font-medium text-gray-500">
                  <div className="flex items-center gap-1.5 bg-gray-50 px-2.5 py-1 rounded-lg border border-gray-100/50">
                    <MapPin className="w-3.5 h-3.5 text-primary-500" />
                    <span className="truncate max-w-[150px]">{item.location?.address || 'Kolhapur City'}</span>
                  </div>
                  <div className="flex items-center gap-1.5 bg-gray-50 px-2.5 py-1 rounded-lg border border-gray-100/50">
                    <Calendar className="w-3.5 h-3.5 text-orange-500" />
                    <span>{new Date(item.createdAt).toLocaleDateString()}</span>
                  </div>
                </div>
              </div>

              <div className="mt-4 pt-4 border-t border-gray-50 flex flex-wrap gap-2 justify-end items-center">
                {!item.isDemo && (
                  <button 
                    onClick={() => setShowLogs(item._id)}
                    className="flex items-center gap-2 px-4 py-1.5 rounded-lg text-xs font-bold text-primary-700 bg-primary-50 hover:bg-primary-100 border border-primary-100 transition-all shadow-sm"
                  >
                    <Layers className="w-3.5 h-3.5" />
                    Blockchain Logs
                  </button>
                )}

                {role === 'admin' && !item.isDemo && (
                  <>
                    {item.status === 'Pending' && (
                      <button onClick={() => handleAssign(item._id)} className="btn-primary text-xs flex items-center gap-1.5 py-1.5 shadow-md shadow-primary-200">
                        Dispatch Crew
                      </button>
                    )}
                    {item.status === 'In Progress' && (
                      <button onClick={() => handleStatusUpdate(item._id, 'Resolved')} className="bg-green-600 hover:bg-green-700 text-white px-4 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-2">
                        Complete Task
                      </button>
                    )}
                  </>
                )}

                {role === 'citizen' && item.status === 'Pending' && (
                  <button onClick={() => handleEscalate(item._id)} className="bg-red-50 text-red-600 border border-red-100 hover:bg-red-600 hover:text-white px-4 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5">
                    <AlertTriangle className="w-3.5 h-3.5" />
                    Escalate
                  </button>
                )}

                {role === 'citizen' && item.status === 'Resolved' && (
                  <div className="flex items-center gap-1 bg-yellow-50 px-3 py-1 rounded-lg border border-yellow-100 mr-auto">
                    <span className="text-xs font-bold text-yellow-700 mr-2 uppercase tracking-wide">Rate Fix</span>
                    {[1, 2, 3, 4, 5].map((star) => (
                       <Star key={star} onClick={() => handleRating(item._id, star)} className="w-4 h-4 text-yellow-400 hover:fill-yellow-400 cursor-pointer transition-colors" />
                    ))}
                  </div>
                )}

                {role === 'citizen' && (
                  <div className="flex items-center gap-2">
                     <button onClick={() => shareSocial('WhatsApp', item.title)} className="w-8 h-8 rounded-full bg-green-50 text-green-600 flex items-center justify-center hover:bg-green-600 hover:text-white transition-colors" title="Share to WhatsApp">
                        <MessageCircle className="w-4 h-4" />
                     </button>
                     <button onClick={() => shareSocial('Twitter', item.title)} className="w-8 h-8 rounded-full bg-blue-50 text-blue-400 flex items-center justify-center hover:bg-blue-400 hover:text-white transition-colors" title="Share to Twitter">
                        <Share2 className="w-4 h-4" />
                     </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      {filteredData.length === 0 && (
        <div className="card h-64 flex flex-col items-center justify-center text-center">
          <div className="w-16 h-16 bg-gray-50 rounded-full flex items-center justify-center mb-4 text-gray-300">
            <Filter className="w-8 h-8" />
          </div>
          <h3 className="text-lg font-bold">No complaints found</h3>
          <p className="text-sm text-gray-400 max-w-xs mt-1">
            Try reporting a new issue to see it here on the blockchain.
          </p>
        </div>
      )}
    </div>
  );
};

export default ComplaintList;
