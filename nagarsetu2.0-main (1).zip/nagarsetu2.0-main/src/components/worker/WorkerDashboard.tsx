import React, { useState, useRef, useEffect } from 'react';
import { MapPin, Clock, CheckCircle2, Upload, Camera, AlertCircle } from 'lucide-react';
import SLATimer from '../common/SLATimer';
import { complaintService } from '../../services/api';

const mockTasks: any[] = [
  {
    id: 'TSK-9921',
    title: 'Repair Large Pothole',
    location: { address: 'Main St & Broadway' },
    priority: 'high',
    status: 'assigned',
    timeRemaining: { h: 1, m: 45 },
    description: 'Hazardous pothole reported by multiple citizens. Immediate patch required.',
    image: 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&q=80&w=200'
  },
  {
    id: 'TSK-9922',
    title: 'Fix Broken Street Light',
    location: { address: '12th Ave, Sunset District' },
    priority: 'medium',
    status: 'assigned',
    timeRemaining: { h: 4, m: 30 },
    description: 'Bulb replacement and wiring check needed on pole #402.',
    image: 'https://images.unsplash.com/photo-1470115636492-6d2b56f9146d?auto=format&fit=crop&q=80&w=200'
  }
];

const WorkerDashboard = () => {
  const [tasks, setTasks] = useState(mockTasks);
  const [selectedTask, setSelectedTask] = useState<string | null>(null);

  useEffect(() => {
    const fetchAssigned = async () => {
      try {
        const { data } = await complaintService.getComplaints();
        const inProgress = data
          .filter((d: any) => d.status === 'In Progress')
          .map((d: any) => ({
             id: d._id,
             title: d.title,
             location: d.location || { address: 'Kolhapur' },
             priority: d.priority || 'medium',
             status: 'assigned',
             timeRemaining: { h: 6, m: 0 },
             description: d.description,
             image: d.imageUrl || 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&q=80&w=200',
             isReal: true
          }));
        setTasks([...inProgress, ...mockTasks]);
      } catch (e) {
        console.error(e);
      }
    };

    fetchAssigned();

    // Live Assignment Tracking
    const subscription = complaintService.subscribeToComplaints(() => {
      fetchAssigned();
    });

    return () => {
      subscription.unsubscribe();
    };
  }, []);
  const [proofImage, setProofImage] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleImageCapture = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (!file.type.startsWith('image/')) {
        alert('Please select an image file.');
        return;
      }
      setProofImage(URL.createObjectURL(file));
    }
  };

  const handleComplete = async (id: string) => {
    if (!proofImage) return;
    
    // If it's a real task
    const task = tasks.find(t => t.id === id);
    if (task && task.isReal) {
      const formData = new FormData();
      formData.append('status', 'Resolved');
      
      // Send the actual file captured
      if (fileInputRef.current?.files?.[0]) {
        formData.append('image', fileInputRef.current.files[0]);
      }

      try {
        await complaintService.updateComplaint(id, formData);
      } catch (err) {
        console.error('Failed to sync to database', err);
      }
    }

    setTasks(t => t.map(task => task.id === id ? { ...task, status: 'completed', proofImage } : task));
    setSelectedTask(null);
    setProofImage(null);
    alert('Task marked as completed! Proof of work uploaded & Synchronized.');
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold">My Task List</h2>
          <p className="text-gray-500">Assigned maintenance tasks for Field Squad A.</p>
        </div>
        <div className="flex gap-4 p-3 bg-white rounded-2xl border border-gray-100 shadow-sm">
          <div className="text-center px-4 border-r border-gray-100">
            <p className="text-2xl font-bold text-gray-900">{tasks.filter(t => t.status === 'assigned').length}</p>
            <p className="text-[10px] uppercase font-bold text-gray-400">Pending</p>
          </div>
          <div className="text-center px-4 border-r border-gray-100">
            <p className="text-2xl font-bold text-orange-500">{tasks.filter(t => t.priority === 'high').length}</p>
            <p className="text-[10px] uppercase font-bold text-gray-400">Urgent</p>
          </div>
          <div className="text-center px-4">
            <p className="text-2xl font-bold text-green-500">{tasks.filter(t => t.status === 'completed').length}</p>
            <p className="text-[10px] uppercase font-bold text-gray-400">Completed</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {tasks.map(task => (
           <div key={task.id} className={`card overflow-hidden border-2 transition-all ${
             task.status === 'completed' ? 'border-green-100 bg-green-50/10' : 
             task.priority === 'high' ? 'border-orange-200' : 'border-transparent'
           }`}>
             
             {task.priority === 'high' && task.status !== 'completed' && (
               <div className="bg-orange-500 text-white text-[10px] font-bold uppercase tracking-wider py-1 px-4 mb-4 -mx-6 -mt-6 flex items-center justify-center gap-2">
                 <AlertCircle className="w-3 h-3" /> Priority Task
               </div>
             )}

             <div className="flex justify-between items-start mb-4">
                <div>
                  <span className="text-xs font-bold text-gray-400 uppercase tracking-wider bg-gray-50 px-2 py-0.5 rounded mr-2">
                    {task.id}
                  </span>
                  <h3 className={`text-xl font-bold mt-2 ${task.status === 'completed' ? 'line-through text-gray-400' : 'text-gray-900'}`}>
                    {task.title}
                  </h3>
                </div>
                {task.status !== 'completed' && (
                  <SLATimer initialHours={task.timeRemaining.h} initialMinutes={task.timeRemaining.m} priority={task.priority as any} />
                )}
             </div>

             <div className="flex gap-4 mb-6">
                <div className="w-20 h-20 rounded-lg overflow-hidden shrink-0">
                  <img src={task.image} className={`w-full h-full object-cover ${task.status === 'completed' ? 'grayscale opacity-50' : ''}`} />
                </div>
                <div className="flex-1 space-y-2">
                  <p className="text-sm text-gray-600 line-clamp-2">{task.description}</p>
                  <div className="flex items-center gap-1.5 text-xs font-medium text-gray-500 bg-gray-50 px-2.5 py-1.5 rounded-lg inline-flex">
                    <MapPin className="w-3.5 h-3.5 text-primary-500" />
                    <span>{task.location?.address || 'Kolhapur City'}</span>
                  </div>
                </div>
             </div>

             {task.status === 'completed' ? (
                <div className="space-y-4">
                  <div className="w-full py-3 bg-green-100 text-green-700 rounded-xl font-bold flex items-center justify-center gap-2 text-sm shadow-sm">
                    <CheckCircle2 className="w-5 h-5" />
                    Task Completed Successfully
                  </div>
                  {(task as any).proofImage && (
                     <div className="relative rounded-xl overflow-hidden border-2 border-green-200">
                       <img src={(task as any).proofImage} className="w-full h-40 object-cover" alt="Proof of work" />
                       <div className="absolute top-2 left-2 bg-black/60 backdrop-blur-sm text-white text-[10px] font-bold px-2 py-1 rounded uppercase flex items-center gap-1 shadow-md">
                          <CheckCircle2 className="w-3 h-3 text-green-400" /> After Work Proof
                       </div>
                     </div>
                  )}
                </div>
             ) : (
                <>
                  {selectedTask === task.id ? (
                    <div className="space-y-4 animate-in slide-in-from-top-2">
                      {!proofImage ? (
                        <div 
                          onClick={() => fileInputRef.current?.click()}
                          className="w-full h-32 border-2 border-dashed border-gray-300 hover:border-primary-400 hover:bg-primary-50 rounded-xl bg-gray-50 flex flex-col items-center justify-center text-gray-500 cursor-pointer transition-all group"
                        >
                          <Camera className="w-8 h-8 mb-2 group-hover:text-primary-500 transition-colors group-hover:scale-110" />
                          <span className="text-sm font-bold text-gray-600 group-hover:text-primary-600">Tap to capture proof of work</span>
                          <span className="text-xs text-gray-400 mt-1">Camera or Gallery</span>
                        </div>
                      ) : (
                        <div className="relative w-full h-40 rounded-xl overflow-hidden border-2 border-primary-200 shadow-md">
                          <img src={proofImage} className="w-full h-full object-cover" alt="Preview" />
                          <div className="absolute top-2 left-2 bg-black/50 text-white text-xs font-bold px-2 py-1 rounded backdrop-blur-sm">
                            Preview
                          </div>
                          <button 
                            onClick={() => setProofImage(null)}
                            className="absolute top-2 right-2 bg-red-500 hover:bg-red-600 text-white text-xs font-bold px-3 py-1.5 rounded-lg shadow-lg transition-colors"
                          >
                            Retake
                          </button>
                        </div>
                      )}
                      
                      <input 
                        type="file" 
                        ref={fileInputRef} 
                        onChange={handleImageCapture}
                        accept="image/*" 
                        capture="environment" 
                        className="hidden" 
                      />

                      <div className="flex gap-2">
                        <button onClick={() => { setSelectedTask(null); setProofImage(null); }} className="flex-1 py-3 text-sm font-bold text-gray-500 hover:bg-gray-100 rounded-xl transition-colors">
                          Cancel
                        </button>
                        <button 
                          onClick={() => handleComplete(task.id)} 
                          disabled={!proofImage}
                          className={`flex-[2] flex justify-center items-center gap-2 shadow-lg transition-all rounded-xl font-bold py-3 ${
                            proofImage 
                            ? 'bg-primary-600 hover:bg-primary-700 text-white shadow-primary-200' 
                            : 'bg-gray-200 text-gray-400 cursor-not-allowed shadow-none'
                          }`}
                        >
                          <CheckCircle2 className="w-5 h-5" /> 
                          {proofImage ? 'Complete Task' : 'Upload Proof First'}
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="flex gap-2">
                       <button className="flex-1 py-3 bg-gray-50 hover:bg-gray-100 text-gray-700 rounded-xl font-bold text-sm transition-colors border border-gray-200 flex items-center justify-center gap-2">
                         <MapPin className="w-4 h-4" /> Navigate
                       </button>
                       <button onClick={() => setSelectedTask(task.id)} className="flex-[2] bg-primary-600 hover:bg-primary-700 text-white rounded-xl font-bold text-sm transition-all shadow-md shadow-primary-200 flex items-center justify-center gap-2">
                         <Upload className="w-4 h-4" /> Resolve & Upload Proof
                       </button>
                    </div>
                  )}
                </>
             )}
           </div>
        ))}

        {tasks.length === 0 && (
          <div className="col-span-1 lg:col-span-2 card flex flex-col items-center justify-center h-64">
            <CheckCircle2 className="w-16 h-16 text-green-500 mb-4" />
            <h3 className="text-xl font-bold text-gray-900">All caught up!</h3>
            <p className="text-gray-500 mt-2">No pending tasks for your squad right now.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default WorkerDashboard;
