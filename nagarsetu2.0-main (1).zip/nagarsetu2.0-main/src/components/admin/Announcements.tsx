import React, { useState } from 'react';
import { Megaphone, Send, Clock, Globe2 } from 'lucide-react';

const Announcements = () => {
  const [broadcasts, setBroadcasts] = useState([
    { id: 1, title: 'Heavy Rainfall Alert', msg: 'Field squads be advised: Heavy rainfall expected this evening in Kolhapur West. Priority on water-logging complaints.', time: '1 hour ago', targets: 'All Staff' },
    { id: 2, title: 'Road Expansion Update', msg: 'Phase 2 of the Highway project begins Monday. Expect high volume of detour-related complaints.', time: 'Yesterday', targets: 'Admins & Workers' }
  ]);
  const [title, setTitle] = useState('');
  const [msg, setMsg] = useState('');

  const sendBroadcast = () => {
    if (!title || !msg) return alert('Fill in all fields');
    setBroadcasts([{ id: Date.now(), title, msg, time: 'Just now', targets: 'All Networks' }, ...broadcasts]);
    setTitle('');
    setMsg('');
    alert('Broadcast dispatched successfully!');
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold">System Broadcasting</h2>
          <p className="text-gray-500">Dispatch network-wide notices, weather alerts, and squad directions.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-1 space-y-4">
          <div className="card p-6 border-primary-200 shadow-primary-50 rounded-2xl">
            <div className="flex items-center gap-3 mb-6">
               <div className="w-10 h-10 bg-primary-100 text-primary-600 rounded-full flex items-center justify-center">
                 <Megaphone className="w-5 h-5" />
               </div>
               <h3 className="text-lg font-bold">New Notification</h3>
            </div>
            
            <div className="space-y-4">
              <div className="space-y-1">
                 <label className="text-xs font-bold text-gray-500 uppercase">Alert Title</label>
                 <input value={title} onChange={(e)=>setTitle(e.target.value)} type="text" className="input-field" placeholder="e.g. Critical Update" />
              </div>
              <div className="space-y-1">
                 <label className="text-xs font-bold text-gray-500 uppercase">Message Body</label>
                 <textarea value={msg} onChange={(e)=>setMsg(e.target.value)} rows={4} className="input-field resize-none" placeholder="Enter broadcast contents..."></textarea>
              </div>
              <div className="space-y-1">
                 <label className="text-xs font-bold text-gray-500 uppercase">Target Audience</label>
                 <select className="input-field cursor-pointer">
                   <option>All Network</option>
                   <option>Citizens Only</option>
                   <option>Field Squads Only</option>
                 </select>
              </div>
              <button onClick={sendBroadcast} className="w-full btn-primary flex items-center justify-center gap-2 py-3 mt-4">
                 <Send className="w-5 h-5" /> Dispatch Alert
              </button>
            </div>
          </div>
        </div>
        
        <div className="lg:col-span-2 card p-0 overflow-hidden">
           <div className="p-6 border-b border-gray-50">
             <h3 className="text-lg font-bold">Recent Broadcasts</h3>
           </div>
           <div className="divide-y divide-gray-50">
             {broadcasts.map(b => (
               <div key={b.id} className="p-6 hover:bg-gray-50/50 transition-colors">
                 <div className="flex justify-between items-start mb-2">
                   <h4 className="font-bold text-gray-900 text-lg">{b.title}</h4>
                   <span className="flex items-center gap-1.5 text-xs text-gray-500 font-medium bg-gray-100 px-2 py-1 rounded">
                     <Clock className="w-3.5 h-3.5" /> {b.time}
                   </span>
                 </div>
                 <p className="text-gray-600 text-sm">{b.msg}</p>
                 <div className="mt-4 flex items-center gap-2">
                   <Globe2 className="w-4 h-4 text-primary-400" />
                   <span className="text-xs font-bold text-gray-400 uppercase tracking-widest">{b.targets}</span>
                 </div>
               </div>
             ))}
           </div>
        </div>
      </div>
    </div>
  );
};

export default Announcements;
