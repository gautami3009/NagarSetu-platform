import React from 'react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip as RechartsTooltip, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
  Legend
} from 'recharts';

const dailyData = [
  { name: 'Mon', reported: 45, resolved: 30 },
  { name: 'Tue', reported: 52, resolved: 38 },
  { name: 'Wed', reported: 38, resolved: 42 },
  { name: 'Thu', reported: 65, resolved: 45 },
  { name: 'Fri', reported: 48, resolved: 55 },
  { name: 'Sat', reported: 35, resolved: 20 },
  { name: 'Sun', reported: 28, resolved: 25 },
];

const categoryData = [
  { name: 'Roads & Streets', value: 450, color: '#0ea5e9' },
  { name: 'Utilities', value: 320, color: '#f59e0b' },
  { name: 'Sanitation', value: 280, color: '#10b981' },
  { name: 'Public Safety', value: 150, color: '#8b5cf6' },
  { name: 'Other', value: 84, color: '#94a3b8' },
];

const resolutionTimeData = [
  { time: '0-2 hours', count: 120 },
  { time: '2-6 hours', count: 350 },
  { time: '6-24 hours', count: 420 },
  { time: '1-3 days', count: 210 },
  { time: '>3 days', count: 85 },
];

const AnalyticsDashboard = () => {
  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-extrabold text-gray-900 tracking-tight">Advanced Analytics</h1>
          <p className="text-gray-500 mt-1">Deep dive into city maintenance metrics and trends.</p>
        </div>
        <select className="px-4 py-2 bg-white border border-gray-200 rounded-xl font-bold text-sm outline-none focus:ring-2 focus:ring-primary-100">
          <option>Last 7 Days</option>
          <option>Last 30 Days</option>
          <option>This Year</option>
        </select>
      </div>

      {/* Summary Row */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
         <div className="card bg-primary-600 text-white border-transparent">
           <p className="text-primary-100 font-bold mb-1">Total Complaints</p>
           <h3 className="text-4xl font-extrabold">1,284</h3>
           <p className="text-sm text-primary-200 mt-2">+12% vs previous period</p>
         </div>
         <div className="card">
           <p className="text-gray-500 font-bold mb-1">Pending Resolution</p>
           <h3 className="text-4xl font-extrabold text-yellow-500">432</h3>
           <p className="text-sm text-gray-400 mt-2">15% critical priority</p>
         </div>
         <div className="card">
           <p className="text-gray-500 font-bold mb-1">Successfully Resolved</p>
           <h3 className="text-4xl font-extrabold text-green-500">852</h3>
           <p className="text-sm text-gray-400 mt-2">66.3% resolution rate</p>
         </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Reported vs Resolved Chart */}
        <div className="card h-96 flex flex-col">
          <h3 className="text-lg font-bold mb-6">Reported vs. Resolved (Daily)</h3>
          <div className="flex-1 min-h-0">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={dailyData} margin={{ top: 5, right: 30, left: -20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f3f4f6" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#6b7280' }} dy={10} />
                <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#6b7280' }} />
                <RechartsTooltip contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }} />
                <Legend iconType="circle" wrapperStyle={{ fontSize: '12px', paddingTop: '10px' }} />
                <Line type="monotone" dataKey="reported" name="Reported Issues" stroke="#f59e0b" strokeWidth={3} dot={{ r: 4, strokeWidth: 2 }} activeDot={{ r: 6 }} />
                <Line type="monotone" dataKey="resolved" name="Resolved Issues" stroke="#10b981" strokeWidth={3} dot={{ r: 4, strokeWidth: 2 }} activeDot={{ r: 6 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Complaints by Category Chart */}
        <div className="card h-96 flex flex-col">
          <h3 className="text-lg font-bold mb-6">Complaints by Category</h3>
          <div className="flex-1 min-h-0 flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={categoryData}
                  cx="50%"
                  cy="50%"
                  innerRadius={70}
                  outerRadius={100}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {categoryData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <RechartsTooltip 
                  formatter={(value: any) => [`${value} Issues`, 'Count']}
                  contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }} 
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-2 mt-4 max-w-full">
            {categoryData.map((item) => (
              <div key={item.name} className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full shrink-0" style={{ backgroundColor: item.color }}></div>
                <span className="text-xs font-medium text-gray-600 truncate">{item.name} ({item.value})</span>
              </div>
            ))}
          </div>
        </div>
        
        {/* Resolution Time Distribution */}
        <div className="card h-96 lg:col-span-2 flex flex-col">
          <h3 className="text-lg font-bold mb-6">Resolution Time Distribution</h3>
          <div className="flex-1 min-h-0">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={resolutionTimeData} margin={{ top: 5, right: 30, left: -20, bottom: 5 }} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" horizontal={true} vertical={false} stroke="#f3f4f6" />
                <XAxis type="number" axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#6b7280' }} />
                <YAxis dataKey="time" type="category" axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#6b7280' }} width={80} />
                <RechartsTooltip cursor={{ fill: '#f8fafc' }} contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }} />
                <Bar dataKey="count" fill="#3b82f6" radius={[0, 6, 6, 0]} barSize={24} name="Issue Count" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AnalyticsDashboard;
