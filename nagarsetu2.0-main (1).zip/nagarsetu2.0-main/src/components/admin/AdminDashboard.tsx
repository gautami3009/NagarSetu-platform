import React from 'react';
import { 
  Users, 
  Clock, 
  CheckCircle2, 
  AlertCircle,
  TrendingUp,
  MapPin
} from 'lucide-react';
import StatCard from '../dashboard/StatCard';
import { ActivityChart, DistributionChart } from '../dashboard/DashboardChart';
import LeaderboardCard from '../dashboard/LeaderboardCard';
import { reportService } from '../../services/api';

const AdminDashboard = () => {
  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-extrabold text-gray-900 tracking-tight">Admin Overview</h1>
          <p className="text-gray-500 mt-1">High-level insights into city operations and squad performance.</p>
        </div>
        <div className="flex gap-2">
            <button onClick={() => reportService.downloadReport('csv')} className="px-4 py-2 bg-white text-gray-700 border border-gray-200 rounded-xl font-bold text-sm hover:bg-gray-50 transition-colors">
              Export CSV
            </button>
            <button onClick={() => reportService.downloadReport('pdf')} className="btn-primary py-2 text-sm flex items-center gap-2">
              Generate PDF Report
            </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard 
          title="Avg. Resolution Time" 
          value="4.2 Hrs" 
          icon={Clock} 
          trend="-15%" 
          trendUp={true} 
          color="green" 
        />
        <StatCard 
          title="Escalated Issues" 
          value="24" 
          icon={AlertCircle} 
          trend="+5%" 
          trendUp={false} 
          color="red" 
        />
        <StatCard 
          title="Active Personnel" 
          value="142" 
          icon={Users} 
          trend="Stable" 
          trendUp={true} 
          color="blue" 
        />
        <StatCard 
          title="Citizen Satisfaction" 
          value="4.8/5" 
          icon={TrendingUp} 
          trend="+0.2" 
          trendUp={true} 
          color="yellow" 
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <ActivityChart />
        </div>
        <div>
          <DistributionChart />
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 card">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-bold">Hotspots & Alerts</h3>
            <button className="text-primary-600 text-sm font-bold hover:underline">View Map</button>
          </div>
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="flex gap-4 p-4 rounded-xl border border-red-100 bg-red-50/50">
                <div className="w-10 h-10 rounded-full bg-red-100 flex items-center justify-center text-red-600 shrink-0">
                  <MapPin className="w-5 h-5" />
                </div>
                <div className="flex-1">
                  <div className="flex justify-between items-start">
                    <p className="text-sm font-bold text-gray-900">High concentration of Potholes</p>
                    <span className="text-xs font-bold text-red-600 bg-red-100 px-2 py-0.5 rounded">CRITICAL</span>
                  </div>
                  <p className="text-xs text-gray-500 mt-1">Downtown / Market Street • 12 active reports</p>
                </div>
              </div>
            ))}
          </div>
        </div>
        <div>
          <LeaderboardCard />
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
