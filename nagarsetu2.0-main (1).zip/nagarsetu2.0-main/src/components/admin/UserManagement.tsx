import React, { useState } from 'react';
import { Users, UserPlus, Mail, Shield, Trash2, Edit2 } from 'lucide-react';

const MOCK_USERS = [
  { id: 'usr_1', name: 'Ravi Kumar', email: 'ravi.k@nashik.gov', role: 'admin', status: 'active', department: 'City Management' },
  { id: 'usr_2', name: 'Amit Patil', email: 'apatil.crew@nashik.gov', role: 'worker', status: 'active', department: 'Roads & Tracking' },
  { id: 'usr_3', name: 'Sneha Joshi', email: 'sneha.j@nashik.gov', role: 'citizen', status: 'active', department: 'N/A' },
  { id: 'usr_4', name: 'Sanjay Deshmukh', email: 's.deshmukh@nashik.gov', role: 'worker', status: 'inactive', department: 'Waste Management' },
];

const UserManagement = () => {
  const [users, setUsers] = useState(MOCK_USERS);
  const [showAddModal, setShowAddModal] = useState(false);

  const RoleBadge = ({ role }: { role: string }) => {
    switch (role) {
      case 'admin': return <span className="bg-purple-100 text-purple-700 px-2 py-1 rounded text-[10px] font-bold uppercase tracking-wider">Admin</span>;
      case 'worker': return <span className="bg-blue-100 text-blue-700 px-2 py-1 rounded text-[10px] font-bold uppercase tracking-wider">Field Squad</span>;
      default: return <span className="bg-gray-100 text-gray-700 px-2 py-1 rounded text-[10px] font-bold uppercase tracking-wider">Citizen</span>;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold">Personnel & Roles</h2>
          <p className="text-gray-500">Manage access levels and squad assignments.</p>
        </div>
        <button 
          onClick={() => setShowAddModal(true)}
          className="btn-primary flex items-center gap-2"
        >
          <UserPlus className="w-5 h-5" /> Add Member
        </button>
      </div>

      <div className="card p-0 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="bg-gray-50 border-b border-gray-100 text-gray-500 font-bold uppercase tracking-wider text-[10px]">
              <tr>
                <th className="p-4">Name</th>
                <th className="p-4">Role</th>
                <th className="p-4">Department</th>
                <th className="p-4">Status</th>
                <th className="p-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {users.map(u => (
                <tr key={u.id} className="hover:bg-gray-50/50 transition-colors">
                  <td className="p-4">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-primary-100 text-primary-700 flex items-center justify-center font-bold font-mono">
                        {u.name.charAt(0)}
                      </div>
                      <div>
                        <p className="font-bold text-gray-900">{u.name}</p>
                        <p className="text-xs text-gray-500 flex items-center gap-1"><Mail className="w-3 h-3" /> {u.email}</p>
                      </div>
                    </div>
                  </td>
                  <td className="p-4"><RoleBadge role={u.role} /></td>
                  <td className="p-4 text-gray-600 font-medium">{u.department}</td>
                  <td className="p-4">
                    <span className={`flex items-center gap-1.5 text-xs font-bold ${u.status === 'active' ? 'text-green-600' : 'text-red-500'}`}>
                      <div className={`w-2 h-2 rounded-full ${u.status === 'active' ? 'bg-green-500' : 'bg-red-500'}`}></div>
                      {u.status}
                    </span>
                  </td>
                  <td className="p-4 text-right">
                    <button className="p-1.5 text-gray-400 hover:text-primary-600 hover:bg-primary-50 rounded transition-colors mr-2">
                      <Edit2 className="w-4 h-4" />
                    </button>
                    <button 
                      onClick={() => {
                        if(confirm('Revoke access for this user?')) {
                          setUsers(users.filter(x => x.id !== u.id));
                        }
                      }}
                      className="p-1.5 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {showAddModal && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl w-full max-w-md shadow-2xl p-6 animate-in zoom-in-95">
            <h3 className="text-xl font-bold mb-4">Add Network Member</h3>
            <div className="space-y-4">
              <div className="space-y-1">
                 <label className="text-xs font-bold text-gray-500 uppercase">Full Name</label>
                 <input type="text" className="input-field" placeholder="e.g. Rahul Sharma" />
              </div>
              <div className="space-y-1">
                 <label className="text-xs font-bold text-gray-500 uppercase">Email Address</label>
                 <input type="email" className="input-field" placeholder="rahul@nashik.gov" />
              </div>
              <div className="space-y-1">
                 <label className="text-xs font-bold text-gray-500 uppercase">System Role</label>
                 <select className="input-field cursor-pointer">
                   <option>Worker (Field Squad)</option>
                   <option>Admin</option>
                 </select>
              </div>
            </div>
            <div className="flex gap-3 mt-8">
              <button onClick={() => setShowAddModal(false)} className="flex-1 py-2 font-bold text-gray-500 hover:bg-gray-100 rounded-xl transition-colors">
                Cancel
              </button>
              <button 
                onClick={() => {
                  alert('Member invite sent successfully.');
                  setShowAddModal(false);
                }}
                className="flex-1 btn-primary py-2 shadow-md shadow-primary-200"
              >
                Send Invite
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default UserManagement;
