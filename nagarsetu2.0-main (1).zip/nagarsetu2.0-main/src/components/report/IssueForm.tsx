import React, { useState } from 'react';
import { MapPin, Info, Send, Calendar, Sparkles, Loader2 } from 'lucide-react';
import { MapContainer, TileLayer, Marker, Popup, useMapEvents } from 'react-leaflet';
import L from 'leaflet';
import EXIF from 'exif-js';
import ImageUpload from './ImageUpload';

const getDecimalCoord = (coord: any, ref: string) => {
  if (!coord) return null;
  const degrees = coord[0].numerator / coord[0].denominator;
  const minutes = coord[1].numerator / coord[1].denominator;
  const seconds = coord[2].numerator / coord[2].denominator;
  let decimal = degrees + (minutes / 60) + (seconds / 3600);
  if (ref === 'S' || ref === 'W') decimal = -decimal;
  return decimal;
};

const iconBlue = new L.DivIcon({
  className: 'custom-leaflet-icon',
  html: `<div style="background-color: #3b82f6; width: 24px; height: 24px; border-radius: 50%; border: 3px solid white; box-shadow: 0 2px 5px rgba(0,0,0,0.3); display: flex; align-items: center; justify-center: center;"></div>`,
  iconSize: [24, 24],
  iconAnchor: [12, 12],
  popupAnchor: [0, -12]
});

const LocationMarker = ({ position, setPosition }: any) => {
  useMapEvents({
    click(e) {
      setPosition(e.latlng);
    },
  });
  return position === null ? null : (
    <Marker position={position} icon={iconBlue}>
      <Popup className="rounded-xl font-bold text-sm">Issue Location</Popup>
    </Marker>
  );
};

import { complaintService } from '../../services/api';

const IssueForm = () => {
  const [markerPos, setMarkerPos] = useState<any>(null);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [address, setAddress] = useState('');
  const [locSource, setLocSource] = useState<'Manual' | 'Image' | 'GPS'>('Manual');
  
  // AI Form state
  const [isProcessing, setIsProcessing] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [aiFailed, setAiFailed] = useState(false);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('Road & Pavement');
  const [priority, setPriority] = useState('Medium');

  const handleImageUploaded = (file: File) => {
    setSelectedFile(file);
    setIsProcessing(true);
    setAiFailed(false);
    
    console.group('🛡️ NagarSetu AI Vision Engine');
    console.log(`Input: ${file.name} (${(file.size / 1024).toFixed(2)} KB)`);
    
    // 1. EXTRACT GEOLOCATION (EXIF)
    EXIF.getData(file as any, function(this: any) {
      const lat = EXIF.getTag(this, "GPSLatitude");
      const latRef = EXIF.getTag(this, "GPSLatitudeRef");
      const lng = EXIF.getTag(this, "GPSLongitude");
      const lngRef = EXIF.getTag(this, "GPSLongitudeRef");

      const decLat = getDecimalCoord(lat, latRef);
      const decLng = getDecimalCoord(lng, lngRef);

      if (decLat && decLng) {
        console.log(`📍 Location Detected from Image: ${decLat.toFixed(5)}, ${decLng.toFixed(5)}`);
        setMarkerPos({ lat: decLat, lng: decLng });
        setLocSource('Image');
        setAddress(`Detected from Image: ${decLat.toFixed(4)}, ${decLng.toFixed(4)}`);
      } else {
        console.log('No geo-tags in image. Requesting browser GPS...');
        navigator.geolocation.getCurrentPosition(
          (pos) => {
            setMarkerPos({ lat: pos.coords.latitude, lng: pos.coords.longitude });
            setLocSource('GPS');
            setAddress(`Current Location: ${pos.coords.latitude.toFixed(4)}, ${pos.coords.longitude.toFixed(4)}`);
          },
          () => console.log('Location detection failed.')
        );
      }
    });

    // 2. AI ANALYZER (Ruleset Based)
    setTimeout(() => {
      const fileName = file.name.toLowerCase();
      let dTitle = 'General Maintenance Point';
      let dDesc = 'A new issue has been logged. Our officials will verify and prioritize this shortly.';
      let dCat = 'Road & Pavement';
      let dPriority = 'Medium';

      if (fileName.includes('pothole') || fileName.includes('road')) {
        dTitle = 'Road Condition Issue';
        dCat = 'Road & Pavement';
        dPriority = 'High';
      } else if (fileName.includes('garbage') || fileName.includes('waste')) {
        dTitle = 'Waste Collection Alert';
        dCat = 'Waste Management';
        dPriority = 'Medium';
      } else if (fileName.includes('water') || fileName.includes('leak')) {
        dTitle = 'Water Infrastructure Leak';
        dCat = 'Water Leakage';
        dPriority = 'High';
      }

      console.log(`✅ Result: ${dCat} | Priority: ${dPriority}`);
      setTitle(dTitle);
      setDescription(dDesc);
      setCategory(dCat);
      setPriority(dPriority);
      setAiFailed(false);
      setIsProcessing(false);
      console.groupEnd();
    }, 2200);
  };

  const handleSubmit = async () => {
    if (!title || !description || !markerPos) {
      alert('Please provide title, description and location on map.');
      return;
    }

    setIsSubmitting(true);
    try {
      const formData = new FormData();
      formData.append('title', title);
      formData.append('description', description);
      formData.append('category', category);
      formData.append('priority', priority);

      // Robust Lat/Lng extraction from object or array formats
      const lat = markerPos.lat ?? (Array.isArray(markerPos) ? markerPos[0] : null);
      const lng = markerPos.lng ?? (Array.isArray(markerPos) ? markerPos[1] : null);
      
      if (lat === null || lng === null) throw new Error("Invalid location data");

      formData.append('lat', lat.toString());
      formData.append('lng', lng.toString());
      formData.append('address', address);
      if (selectedFile) {
        formData.append('image', selectedFile);
      }

      console.log('🚀 Submitting Complaint:', Object.fromEntries(formData.entries()));
      const response = await complaintService.createComplaint(formData);
      console.log('✅ Success:', response);
      alert('Issue reported successfully!');
      // Reset form
      handleReset();
    } catch (err) {
      console.error('❌ API Failure, Falling back to local storage:', err);
      
      // OPTION (NO BACKEND) - Save to localStorage
      const localReport = {
        _id: `LOCAL-${Date.now()}`,
        title,
        description,
        category,
        priority,
        location: {
           lat: markerPos.lat ?? markerPos[0],
           lng: markerPos.lng ?? markerPos[1],
           address: address
        },
        status: 'Pending',
        createdAt: new Date().toISOString(),
        isDemo: false,
        isLocal: true
      };

      try {
        const existing = JSON.parse(localStorage.getItem('local_complaints') || '[]');
        localStorage.setItem('local_complaints', JSON.stringify([localReport, ...existing]));
        alert('Notice: Issue saved locally and will be synced once connection is stable.');
        handleReset();
      } catch (e) {
        console.error('LocalStorage failed:', e);
        alert('Failed to report issue. Please check your connection.');
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleReset = () => {
    setTitle('');
    setDescription('');
    setMarkerPos(null);
    setSelectedFile(null);
    setAddress('');
    setAiFailed(false);
    setPriority('Medium');
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
      <div className="space-y-6">
        <div>
          <h2 className="text-2xl font-bold mb-2">Report New Issue</h2>
          <p className="text-gray-500">Provide details about the issue to help us resolve it quickly.</p>
        </div>

        <ImageUpload onImageSelected={handleImageUploaded} />

        <div className="card space-y-4 relative overflow-hidden">
          {isProcessing && (
            <div className="absolute inset-0 bg-white/80 backdrop-blur-sm z-10 flex flex-col items-center justify-center">
              <Loader2 className="w-8 h-8 text-primary-600 animate-spin mb-2" />
              <p className="text-sm font-bold text-primary-700">AI is analyzing image...</p>
            </div>
          )}

          <div className="flex justify-between items-center mb-2">
            <div className="flex items-center gap-2 text-primary-600">
              <Info className="w-4 h-4" />
              <span className="text-xs font-bold uppercase tracking-wider">Basic Information</span>
            </div>
            {title && !isProcessing && !aiFailed && (
              <span className="flex items-center gap-1 text-[10px] bg-purple-100 text-purple-700 px-2 py-1 rounded font-bold uppercase tracking-wider animate-pulse">
                <Sparkles className="w-3 h-3" /> AI Smart-Fill Active
              </span>
            )}
            {aiFailed && !isProcessing && (
              <span className="flex items-center gap-1 text-[10px] bg-amber-100 text-amber-700 px-2 py-1 rounded font-bold uppercase tracking-wider">
                Manual configuration required
              </span>
            )}
          </div>
          
          <div className="space-y-1">
            <label className="text-sm font-bold text-gray-700">Issue Title</label>
            <input 
              type="text" 
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g., Pothole on Market Street"
              className="w-full px-4 py-2.5 bg-gray-50 border-gray-100 rounded-xl focus:bg-white focus:ring-2 focus:ring-primary-100 transition-all outline-none font-medium"
            />
          </div>

          <div className="space-y-1">
            <label className="text-sm font-bold text-gray-700">Description</label>
            <textarea 
              rows={4}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Describe the issue in detail..."
              className="w-full px-4 py-2.5 bg-gray-50 border-gray-100 rounded-xl focus:bg-white focus:ring-2 focus:ring-primary-100 transition-all outline-none resize-none font-medium text-sm"
            ></textarea>
          </div>
        </div>
      </div>

      <div className="space-y-6">
        <div className="card space-y-4">
          <div className="flex items-center gap-2 text-primary-600 mb-2">
            <MapPin className="w-4 h-4" />
            <span className="text-xs font-bold uppercase tracking-wider">Location Details</span>
          </div>

          <div className="space-y-1">
            <div className="flex justify-between items-center ml-1">
              <label className="text-sm font-bold text-gray-700">Street Address</label>
              {locSource !== 'Manual' && (
                <span className="flex items-center gap-1 text-[10px] font-bold text-green-600 bg-green-50 px-2 py-0.5 rounded animate-bounce">
                  <MapPin className="w-3 h-3" /> {locSource === 'Image' ? 'Detected from Image' : 'Detected via GPS'}
                </span>
              )}
            </div>
            <div className="relative">
              <MapPin className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
              <input 
                type="text" 
                value={address}
                onChange={(e) => {
                  setAddress(e.target.value);
                  setLocSource('Manual');
                }}
                placeholder="Pinpoint location"
                className="w-full pl-10 pr-4 py-2.5 bg-gray-50 border-gray-100 rounded-xl focus:bg-white focus:ring-2 focus:ring-primary-100 transition-all outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1">
              <label className="text-sm font-bold text-gray-700">Category</label>
              <select 
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full px-4 py-2.5 bg-gray-50 border-gray-100 rounded-xl focus:bg-white focus:ring-2 focus:ring-primary-100 transition-all outline-none appearance-none"
              >
                <option>Road & Pavement</option>
                <option>Street Lights</option>
                <option>Waste Management</option>
                <option>Water Leakage</option>
                <option>Other</option>
              </select>
            </div>
            <div className="space-y-1">
              <label className="text-sm font-bold text-gray-700">Priority</label>
              <select 
                value={priority}
                onChange={(e) => setPriority(e.target.value)}
                className="w-full px-4 py-2.5 bg-gray-50 border-gray-100 rounded-xl focus:bg-white focus:ring-2 focus:ring-primary-100 transition-all outline-none appearance-none font-bold"
              >
                <option value="Low">Low</option>
                <option value="Medium">Medium</option>
                <option value="High">High</option>
              </select>
            </div>
          </div>

          <div className="h-48 bg-gray-100 rounded-xl relative overflow-hidden group border border-gray-100 isolation-auto">
            <MapContainer center={[16.7050, 74.2433]} zoom={12} style={{ height: '100%', width: '100%', zIndex: 0 }}>
              <TileLayer
                url="https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png"
              />
              <LocationMarker position={markerPos} setPosition={setMarkerPos} />
            </MapContainer>
            <div className="absolute bottom-2 right-2 bg-white/90 backdrop-blur-sm px-2 py-1 rounded text-[10px] font-bold text-gray-500 uppercase pointer-events-none z-[1000]">
              {markerPos ? 'Location Selected' : 'Click Map to Drop Pin'}
            </div>
          </div>
        </div>

        <button 
          onClick={handleSubmit}
          disabled={isSubmitting}
          className="w-full bg-primary-600 text-white font-bold py-4 rounded-xl shadow-lg shadow-primary-200 hover:bg-primary-700 active:scale-95 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
        >
          {isSubmitting ? <Loader2 className="w-5 h-5 animate-spin" /> : <Send className="w-5 h-5" />}
          {isSubmitting ? 'Submitting...' : 'Submit Issue Report'}
        </button>

        <div className="p-4 bg-primary-50 rounded-xl border border-primary-100 flex gap-3">
          <div className="w-10 h-10 bg-white rounded-lg flex items-center justify-center text-primary-600 shrink-0">
            <Calendar className="w-5 h-5" />
          </div>
          <div>
            <p className="text-xs font-bold text-primary-900 uppercase">Pro Tip</p>
            <p className="text-xs text-primary-700 mt-0.5">Clear photos and accurate locations help staff resolve issues 40% faster on average.</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default IssueForm;
