import React from 'react';
import { Trophy, Medal, Award } from 'lucide-react';

const topUsers = [
  { name: 'Sarah Chen', score: 1240, reports: 42, avatar: 'SC', rank: 1 },
  { name: 'Alex Rivera', score: 980, reports: 35, avatar: 'AR', rank: 2 },
  { name: 'Maria Garcia', score: 850, reports: 28, avatar: 'MG', rank: 3 },
  { name: 'John Doe', score: 720, reports: 24, avatar: 'JD', rank: 4 },
];

const LeaderboardCard = () => {
  return (
    <div className="card">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-bold">Community Leaders</h3>
        <Trophy className="w-5 h-5 text-yellow-500" />
      </div>
      
      <div className="space-y-4">
        {topUsers.map((user) => (
          <div key={user.rank} className="flex items-center gap-3 group">
            <div className="relative">
              <div className="w-10 h-10 rounded-full bg-gray-50 flex items-center justify-center text-sm font-bold border border-gray-100 group-hover:border-primary-200 transition-colors">
                {user.avatar}
              </div>
              {user.rank <= 3 && (
                <div className="absolute -top-1 -right-1">
                  {user.rank === 1 && <Medal className="w-4 h-4 text-yellow-500 fill-yellow-500" />}
                  {user.rank === 2 && <Medal className="w-4 h-4 text-gray-400 fill-gray-400" />}
                  {user.rank === 3 && <Medal className="w-4 h-4 text-orange-400 fill-orange-400" />}
                </div>
              )}
            </div>
            
            <div className="flex-1">
              <p className="text-sm font-bold">{user.name}</p>
              <p className="text-[10px] text-gray-400 font-medium uppercase tracking-wider">
                {user.reports} Reports • {user.score} XP
              </p>
            </div>
            
            <div className="text-xs font-bold text-primary-600 bg-primary-50 px-2.5 py-1 rounded-lg">
              #{user.rank}
            </div>
          </div>
        ))}
      </div>
      
      <button className="w-full mt-6 py-2.5 text-sm font-bold text-gray-400 border border-dashed border-gray-200 rounded-xl hover:border-primary-300 hover:text-primary-600 transition-all">
        View Full Leaderboard
      </button>
    </div>
  );
};

export default LeaderboardCard;
