import React from 'react';
import { LucideIcon, ArrowUpRight, ArrowDownRight } from 'lucide-react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

interface StatCardProps {
  title: string;
  value: string;
  icon: LucideIcon;
  trend: string;
  trendUp?: boolean;
  color: 'blue' | 'yellow' | 'green' | 'red';
}

const colorMap = {
  blue: 'bg-blue-50 text-blue-600 border-blue-100',
  yellow: 'bg-yellow-50 text-yellow-600 border-yellow-100',
  green: 'bg-green-50 text-green-600 border-green-100',
  red: 'bg-red-50 text-red-600 border-red-100',
};

const StatCard: React.FC<StatCardProps> = ({ title, value, icon: Icon, trend, trendUp, color }) => {
  return (
    <div className="card group">
      <div className="flex justify-between items-start mb-4">
        <div className={cn("p-3 rounded-xl border transition-colors", colorMap[color])}>
          <Icon className="w-6 h-6" />
        </div>
        <div className={cn(
          "flex items-center gap-1 text-xs font-bold px-2 py-1 rounded-full",
          trendUp ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"
        )}>
          {trendUp ? <ArrowUpRight className="w-3 h-3" /> : <ArrowDownRight className="w-3 h-3" />}
          {trend}
        </div>
      </div>
      <div>
        <p className="text-sm font-medium text-gray-400 mb-1">{title}</p>
        <h3 className="text-2xl font-bold text-gray-900 group-hover:text-primary-600 transition-colors">
          {value}
        </h3>
      </div>
    </div>
  );
};

export default StatCard;
