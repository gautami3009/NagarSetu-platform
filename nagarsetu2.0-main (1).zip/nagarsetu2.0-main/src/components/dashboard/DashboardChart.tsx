import React, { useEffect, useState } from 'react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from 'recharts';
import { complaintService } from '../../services/api';

const barData = [
  { name: 'Mon', count: 40 },
  { name: 'Tue', count: 30 },
  { name: 'Wed', count: 60 },
  { name: 'Thu', count: 45 },
  { name: 'Fri', count: 70 },
  { name: 'Sat', count: 35 },
  { name: 'Sun', count: 50 },
];

export const ActivityChart = () => (
  <div className="card h-80 flex flex-col pt-6 pl-6 pr-6">
    <h3 className="text-lg font-bold mb-6">Issues Reported (Weekly)</h3>
    <div className="flex-1 min-h-[200px]">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={barData}>
          <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f3f4f6" />
          <XAxis 
            dataKey="name" 
            axisLine={false} 
            tickLine={false} 
            tick={{ fill: '#9ca3af', fontSize: 12 }} 
            dy={10}
          />
          <YAxis 
            axisLine={false} 
            tickLine={false} 
            tick={{ fill: '#9ca3af', fontSize: 12 }} 
          />
          <Tooltip 
            cursor={{ fill: '#f9fafb' }}
            contentStyle={{ 
              borderRadius: '12px', 
              border: 'none', 
              boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1)' 
            }}
          />
          <Bar 
            dataKey="count" 
            fill="#0ea5e9" 
            radius={[6, 6, 0, 0]} 
            barSize={32}
          />
        </BarChart>
      </ResponsiveContainer>
    </div>
  </div>
);

const DEMO_COMPLAINTS = [
  { status: 'Pending' },
  { status: 'Pending' },
  { status: 'In Progress' },
  { status: 'Resolved' },
  { status: 'Resolved' },
  { status: 'Resolved' }
];

export const DistributionChart = () => {
  const [data, setData] = useState<{name: string, value: number, color: string, pct: number}[]>([]);
  const [total, setTotal] = useState(0);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const res = await complaintService.getComplaints();
        const allData = [...res.data, ...DEMO_COMPLAINTS];
        
        let pending = 0;
        let inProgress = 0;
        let resolved = 0;

        allData.forEach((c: any) => {
          if (c.status === 'Pending') pending++;
          else if (c.status === 'In Progress') inProgress++;
          else if (c.status === 'Resolved') resolved++;
        });

        const totalItems = pending + inProgress + resolved;
        setTotal(totalItems);

        setData([
          { name: 'Pending', value: pending, color: '#facc15', pct: Math.round((pending/totalItems)*100) || 0 },        // Yellow
          { name: 'In Progress', value: inProgress, color: '#3b82f6', pct: Math.round((inProgress/totalItems)*100) || 0 }, // Blue
          { name: 'Resolved', value: resolved, color: '#10b981', pct: Math.round((resolved/totalItems)*100) || 0 },    // Green
        ]);

      } catch (err) {
        console.error('Failed to fetch stats', err);
      }
    };
    fetchData();
  }, []);

  return (
    <div className="card h-80 flex flex-col pt-6 px-6">
      <div className="flex justify-between items-start mb-2">
         <h3 className="text-lg font-bold">Status Distribution</h3>
         <div className="bg-primary-50 text-primary-600 px-2.5 py-1 rounded-md text-xs font-bold">
           Total: {total}
         </div>
      </div>
      
      <div className="flex-1 min-h-[160px] relative">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie
              data={data}
              cx="50%"
              cy="50%"
              innerRadius={55}
              outerRadius={75}
              paddingAngle={5}
              dataKey="value"
            >
              {data.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={entry.color} />
              ))}
            </Pie>
            <Tooltip 
              formatter={(value: any, name: any, props: any) => [`${value} Issues (${props.payload.pct}%)`, name]}
              contentStyle={{ 
                borderRadius: '12px', 
                border: 'none', 
                boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1)' 
              }}
            />
          </PieChart>
        </ResponsiveContainer>
        <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
          <span className="text-3xl font-extrabold text-gray-900">{total}</span>
          <span className="text-xs font-bold text-gray-400">Total</span>
        </div>
      </div>
      
      <div className="flex justify-between gap-2 mt-4 pb-4">
        {data.map((item) => (
          <div key={item.name} className="flex flex-col items-center p-2 rounded-xl bg-gray-50 flex-1 border border-transparent hover:border-gray-200 transition-colors">
            <div className="flex items-center gap-1.5 mb-1">
              <div className="w-2.5 h-2.5 rounded-full shadow-sm" style={{ backgroundColor: item.color }}></div>
              <span className="text-[10px] font-bold text-gray-500 uppercase tracking-wide">{item.name}</span>
            </div>
            <div className="flex items-end gap-1">
              <span className="text-lg font-bold text-gray-900 leading-none">{item.value}</span>
              <span className="text-xs font-bold text-gray-400 mb-[2px]">({item.pct}%)</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
