const express = require('express');
const router = express.Router();
const multer = require('multer');
const path = require('path');
const Complaint = require('../models/Complaint');
const AuditLog = require('../models/AuditLog');

// Multer Setup
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'uploads/');
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + path.extname(file.originalname));
  }
});

const upload = multer({ 
  storage: storage,
  fileFilter: (req, file, cb) => {
    const filetypes = /jpeg|jpg|png/;
    const mimetype = filetypes.test(file.mimetype);
    const extname = filetypes.test(path.extname(file.originalname).toLowerCase());
    if (mimetype && extname) {
      return cb(null, true);
    }
    cb(new Error('Only images are allowed'));
  }
});

// Helper to create audit log
const createAuditEntry = async (complaintId, action, status) => {
  const lastEntry = await AuditLog.findOne({ complaintId }).sort({ timestamp: -1 });
  const newLog = new AuditLog({
    complaintId,
    action,
    status,
    previousHash: lastEntry ? lastEntry.hash : '0'.repeat(64)
  });
  await newLog.save();
};

// @route   POST /api/complaints
// @desc    Create a new complaint
router.post('/', upload.single('image'), async (req, res) => {
  try {
    const { title, description, category, lat, lng, address, userId } = req.body;
    
    const newComplaint = new Complaint({
      title,
      description,
      category,
      userId,
      imageUrl: req.file ? `/uploads/${req.file.filename}` : null,
      location: {
        lat: parseFloat(lat),
        lng: parseFloat(lng),
        address
      }
    });

    const complaint = await newComplaint.save();
    
    // Blockchain entry
    await createAuditEntry(complaint._id, 'CREATED', 'Pending');
    
    res.json(complaint);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server Error');
  }
});

// @route   GET /api/complaints
// @desc    Get all complaints
router.get('/', async (req, res) => {
  try {
    const complaints = await Complaint.find().sort({ createdAt: -1 });
    res.json(complaints);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server Error');
  }
});

// @route   GET /api/complaints/:id/logs
// @desc    Get blockchain logs for a complaint
router.get('/:id/logs', async (req, res) => {
  try {
    const logs = await AuditLog.find({ complaintId: req.params.id }).sort({ timestamp: 1 });
    res.json(logs);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server Error');
  }
});

// @route   PUT /api/complaints/:id
// @desc    Update complaint status or add worker notes
router.put('/:id', upload.fields([{ name: 'beforeImage' }, { name: 'afterImage' }]), async (req, res) => {
  try {
    const { status, workerNotes } = req.body;
    let complaint = await Complaint.findById(req.params.id);

    if (!complaint) return res.status(404).json({ msg: 'Complaint not found' });

    const updateFields = {};
    if (status) updateFields.status = status;
    if (workerNotes) updateFields.workerNotes = workerNotes;
    
    if (req.files) {
      if (req.files.beforeImage) updateFields.beforeImageUrl = `/uploads/${req.files.beforeImage[0].filename}`;
      if (req.files.afterImage) updateFields.afterImageUrl = `/uploads/${req.files.afterImage[0].filename}`;
    }

    complaint = await Complaint.findByIdAndUpdate(
      req.params.id,
      { $set: updateFields },
      { new: true }
    );

    // Blockchain entry
    if (status) {
      await createAuditEntry(complaint._id, status === 'Resolved' ? 'RESOLVED' : 'STATUS_UPDATE', status);
    }

    res.json(complaint);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server Error');
  }
});

module.exports = router;
