const express = require('express');
const router = express.Router();
const PDFDocument = require('pdfkit');
const { Parser } = require('json2csv');
const Complaint = require('../models/Complaint');

// @route   GET /api/reports/download
// @desc    Download reports in PDF or CSV format
router.get('/download', async (req, res) => {
  try {
    const { format, userId } = req.query;
    let query = {};
    if (userId) query.userId = userId;

    const complaints = await Complaint.find(query).sort({ createdAt: -1 });

    if (format === 'csv') {
      const fields = ['_id', 'title', 'status', 'category', 'location.address', 'createdAt'];
      const opts = { fields };
      const parser = new Parser(opts);
      const csv = parser.parse(complaints);
      
      res.header('Content-Type', 'text/csv');
      res.attachment('complaints_report.csv');
      return res.send(csv);
    } else {
      // Default to PDF
      const doc = new PDFDocument();
      res.header('Content-Type', 'application/pdf');
      res.attachment('complaints_report.pdf');
      doc.pipe(res);

      doc.fontSize(20).text('NagarSetu - City Infrastructure Report', { align: 'center' });
      doc.moveDown();
      doc.fontSize(12).text(`Generated on: ${new Date().toLocaleString()}`, { align: 'right' });
      doc.moveDown();

      complaints.forEach((c, index) => {
        doc.fontSize(14).text(`${index + 1}. ${c.title}`, { underline: true });
        doc.fontSize(10).text(`Status: ${c.status}`);
        doc.text(`Category: ${c.category}`);
        doc.text(`Location: ${c.location.address || (c.location.lat + ', ' + c.location.lng)}`);
        doc.text(`Date: ${c.createdAt.toLocaleDateString()}`);
        doc.moveDown();
      });

      doc.end();
    }
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server Error');
  }
});

module.exports = router;
